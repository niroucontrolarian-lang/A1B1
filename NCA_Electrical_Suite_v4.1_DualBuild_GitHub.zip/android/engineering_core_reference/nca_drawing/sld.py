
from __future__ import annotations
from dataclasses import dataclass, field

@dataclass
class SldNode:
    id: str
    engineering_object_id: str
    tag: str
    kind: str
    x: float=0
    y: float=0

@dataclass
class SldEdge:
    id: str
    from_node: str
    to_node: str
    connection_type: str="POWER"

@dataclass
class SldGraph:
    nodes: dict[str,SldNode]=field(default_factory=dict)
    edges: list[SldEdge]=field(default_factory=list)
    def add_node(self,n:SldNode):
        if n.id in self.nodes: raise ValueError("Duplicate SLD node id.")
        self.nodes[n.id]=n
    def add_edge(self,e:SldEdge):
        if e.from_node not in self.nodes or e.to_node not in self.nodes:
            raise ValueError("SLD edge endpoint missing.")
        self.edges.append(e)
    def validate(self):
        issues=[]
        tags={}
        for n in self.nodes.values():
            if n.tag in tags: issues.append(f"Duplicate SLD tag: {n.tag}")
            tags[n.tag]=n.id
        return issues
