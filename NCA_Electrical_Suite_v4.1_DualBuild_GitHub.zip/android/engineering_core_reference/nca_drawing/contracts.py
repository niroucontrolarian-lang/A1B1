from dataclasses import dataclass, field

@dataclass
class DrawingSymbolLink:
    drawing_id: str
    symbol_id: str
    engineering_object_id: str
    x: float
    y: float
    layer: str

@dataclass
class DrawingDocument:
    id: str
    document_no: str
    revision: str
    status: str
    symbols: list[DrawingSymbolLink]=field(default_factory=list)
