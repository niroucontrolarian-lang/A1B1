from dataclasses import dataclass
from typing import Any

@dataclass
class PropertyChange:
    object_id: str
    key: str
    base_value: Any
    new_value: Any
    user_id: str

def detect_conflict(a: PropertyChange, b: PropertyChange) -> bool:
    return a.object_id==b.object_id and a.key==b.key and a.new_value!=b.new_value

def can_auto_merge(a: PropertyChange, b: PropertyChange) -> bool:
    return a.object_id!=b.object_id or a.key!=b.key or a.new_value==b.new_value
