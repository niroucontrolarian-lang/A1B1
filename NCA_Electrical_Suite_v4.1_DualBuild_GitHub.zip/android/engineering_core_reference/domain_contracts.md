# Domain contracts

EngineeringObject: id, projectId, parentId, tag, type, status, revision.
AttributeValue: key, value, unit, provenance, sourceRef, confidence, approval.
CalculationResult: calculationId/version, inputSnapshot, evidence, result, status.
ChangeSet: reason, author, items, dependencyImpact, approval state.
DocumentRevision: documentNo, revisionCode/date/status, contentHash, source, confidence.
ManufacturerProduct: manufacturer/category/family/series/model/partNumber/lifecycle/sourceRevision.
