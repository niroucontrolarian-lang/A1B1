from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True)
class Quantity:
    value: float
    unit: str

class UnitError(ValueError): pass

_FACTORS = {
    ("W","kW"): 1e-3, ("kW","W"): 1e3,
    ("kW","MW"): 1e-3, ("MW","kW"): 1e3,
    ("VA","kVA"): 1e-3, ("kVA","VA"): 1e3,
    ("A","mA"): 1e3, ("mA","A"): 1e-3,
    ("ohm","mohm"): 1e3, ("mohm","ohm"): 1e-3,
    ("m","km"): 1e-3, ("km","m"): 1e3,
}

def convert(q: Quantity, to_unit: str) -> Quantity:
    if q.unit == to_unit: return q
    key=(q.unit,to_unit)
    if key not in _FACTORS: raise UnitError(f"Unsupported conversion {q.unit}->{to_unit}")
    return Quantity(q.value*_FACTORS[key], to_unit)
