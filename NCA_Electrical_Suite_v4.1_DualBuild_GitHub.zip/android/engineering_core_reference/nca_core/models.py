from __future__ import annotations
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Optional
from uuid import uuid4
from datetime import datetime, timezone

def new_id() -> str:
    return str(uuid4())

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

class Status(str, Enum):
    DRAFT="DRAFT"; INCOMPLETE="INCOMPLETE"; CALCULATED="CALCULATED"
    WARNING="WARNING"; FAIL="FAIL"; VERIFIED="VERIFIED"; OUTDATED="OUTDATED"
    SOURCE_REQUIRED="SOURCE_REQUIRED"; ENGINEER_APPROVED="ENGINEER_APPROVED"
    FROZEN="FROZEN"; AS_BUILT="AS_BUILT"

class Provenance(str, Enum):
    USER="USER"; CALCULATED="CALCULATED"; ASSUMED="ASSUMED"; MANUFACTURER="MANUFACTURER"

@dataclass
class AttributeValue:
    key: str
    value: Any
    unit: Optional[str] = None
    provenance: Provenance = Provenance.USER
    source_ref: Optional[str] = None
    confidence: Optional[float] = None
    approved: bool = False

@dataclass
class EngineeringObject:
    project_id: str
    object_type: str
    tag: Optional[str] = None
    parent_id: Optional[str] = None
    id: str = field(default_factory=new_id)
    status: Status = Status.DRAFT
    revision: int = 0
    attributes: dict[str, AttributeValue] = field(default_factory=dict)
    created_at: str = field(default_factory=utc_now)
    modified_at: str = field(default_factory=utc_now)

    def set_attr(self, key: str, value: Any, unit: str|None=None,
                 provenance: Provenance=Provenance.USER, source_ref: str|None=None,
                 confidence: float|None=None, approved: bool=False) -> None:
        self.attributes[key] = AttributeValue(
            key, value, unit, provenance, source_ref, confidence, approved
        )
        self.modified_at = utc_now()

    def get(self, key: str, default=None):
        item = self.attributes.get(key)
        return item.value if item else default
