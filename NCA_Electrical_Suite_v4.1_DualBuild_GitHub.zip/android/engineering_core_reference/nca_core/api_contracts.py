
from dataclasses import dataclass, field
from typing import Any

@dataclass
class ApiEnvelope:
    schema_version: int
    request_id: str
    payload: dict[str,Any]

@dataclass
class ApiResult:
    ok: bool
    request_id: str
    payload: dict[str,Any]=field(default_factory=dict)
    errors: list[str]=field(default_factory=list)

API_VERSION="nca-api/0.4"
PROJECT_ENDPOINTS={
 "projects.list":"GET /v1/projects",
 "projects.create":"POST /v1/projects",
 "objects.list":"GET /v1/projects/{project_id}/objects",
 "calculations.run":"POST /v1/calculations/{calculation_id}",
 "bom.generate":"POST /v1/projects/{project_id}/bom",
 "sld.get":"GET /v1/projects/{project_id}/sld",
 "changes.create":"POST /v1/projects/{project_id}/change-sets"
}
