
from dataclasses import dataclass
SUPPORTED=("fa","en","ar","es")
RTL={"fa","ar"}
@dataclass(frozen=True)
class LocaleInfo:
    code:str
    direction:str
def locale_info(code:str)->LocaleInfo:
    if code not in SUPPORTED: raise ValueError("Unsupported locale")
    return LocaleInfo(code,"RTL" if code in RTL else "LTR")
