
from dataclasses import dataclass
@dataclass
class ReleaseDecision:
    allowed:bool
    blockers:list[str]
    message:str

def can_release(gates,open_change_sets=0,revision_conflicts=0):
    blockers=[]
    for g in gates:
        if g.status=="BLOCKED": blockers.append(f"{g.gate}: blocked")
    if open_change_sets: blockers.append(f"{open_change_sets} open change set(s)")
    if revision_conflicts: blockers.append(f"{revision_conflicts} revision conflict(s)")
    return ReleaseDecision(not blockers,blockers,
      "Release permitted." if not blockers else "Release blocked until engineering issues are resolved.")
