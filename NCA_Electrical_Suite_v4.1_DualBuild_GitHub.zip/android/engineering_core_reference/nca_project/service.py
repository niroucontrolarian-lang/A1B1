
from dataclasses import dataclass
from nca_project.database import NcaDatabase

@dataclass
class ProjectService:
    db: NcaDatabase
    def create_reference_motor_project(self):
        pid=self.db.create_project("Golden Reference - 160 kW VFD Motor","NCA-GOLDEN-001")
        source=self.db.add_object(pid,"SOURCE","UTILITY-01")
        tx=self.db.add_object(pid,"TRANSFORMER","TR-01",source,{"rating_kva":None,"uk_percent":None})
        mdb=self.db.add_object(pid,"PANEL","MDB-01",tx)
        mcc=self.db.add_object(pid,"PANEL","MCC-01",mdb)
        vfd=self.db.add_object(pid,"VFD","VFD-101",mcc,{"rated_power_kw":160})
        motor=self.db.add_object(pid,"MOTOR","M-101",vfd,{"power_kw":160,"voltage_v":400,"efficiency":0.95,"power_factor":0.88})
        b=self.db.create_baseline(pid,"B01","Initial Design")
        self.db.set_active_baseline(pid,b)
        return pid
