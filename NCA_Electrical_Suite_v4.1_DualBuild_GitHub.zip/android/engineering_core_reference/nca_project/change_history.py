
import json
class ChangeHistory:
    def __init__(self,con): self.con=con
    def list(self,project_id,limit=100):
        rows=self.con.execute("""SELECT id,object_id,property_key,old_json,new_json,reason,status,created_at,committed_at
          FROM engineering_change WHERE project_id=? ORDER BY created_at DESC LIMIT ?""",(project_id,limit)).fetchall()
        keys=("id","object_id","property_key","old_value","new_value","reason","status","created_at","committed_at")
        out=[]
        for r in rows:
            d=dict(zip(keys,r));d["old_value"]=json.loads(d["old_value"]);d["new_value"]=json.loads(d["new_value"]);out.append(d)
        return out
