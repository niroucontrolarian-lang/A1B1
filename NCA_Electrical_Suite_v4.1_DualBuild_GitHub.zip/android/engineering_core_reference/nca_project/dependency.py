from __future__ import annotations
from collections import defaultdict, deque
from dataclasses import dataclass

@dataclass(frozen=True)
class Node:
    object_id: str
    key: str

class DependencyGraph:
    def __init__(self):
        self.edges: dict[Node,set[Node]] = defaultdict(set)
    def add(self, source: Node, target: Node):
        self.edges[source].add(target)
    def impacted(self, source: Node) -> list[Node]:
        seen=set(); q=deque([source])
        while q:
            cur=q.popleft()
            for nxt in self.edges.get(cur,set()):
                if nxt not in seen:
                    seen.add(nxt); q.append(nxt)
        return list(seen)
