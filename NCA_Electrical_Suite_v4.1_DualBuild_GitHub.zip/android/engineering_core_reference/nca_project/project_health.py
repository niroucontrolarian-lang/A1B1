
from dataclasses import dataclass
@dataclass
class HealthSummary:
    status:str
    counts:dict
    blockers:list[str]

def summarize(status_by_id):
    counts={}
    for s in status_by_id.values(): counts[s]=counts.get(s,0)+1
    blockers=[k for k,v in status_by_id.items() if v in ("FAIL","INCOMPLETE","SOURCE_REQUIRED","OUTDATED")]
    return HealthSummary("ATTENTION_REQUIRED" if blockers else "HEALTHY",counts,blockers)
