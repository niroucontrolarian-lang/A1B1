
from dataclasses import dataclass,field
@dataclass
class OperatingScenario:
    id:str
    name:str
    active_sources:set[str]=field(default_factory=set)
    open_devices:set[str]=field(default_factory=set)
    closed_devices:set[str]=field(default_factory=set)
    notes:str=""
def validate_scenario(s):
    both=s.open_devices & s.closed_devices
    return [] if not both else [f"Device cannot be open and closed simultaneously: {x}" for x in sorted(both)]
