
from .recalculate import RecalculateService
class RecalcWorkflow:
    def __init__(self,ps,review_store,project_id):
        self.ps=ps;self.review_store=review_store;self.project_id=project_id
        self.service=RecalculateService(ps)
    def queue(self):
        return self.service.candidates(self.project_id)
    def recalculate(self,node_id):
        return self.service.mark_recalculated(self.project_id,node_id)
    def approve(self,node_id,reviewer,comment=""):
        nodes={x["node_id"]:x for x in self.ps.load_nodes(self.project_id)}
        if nodes.get(node_id,{}).get("status")!="CALCULATED":
            raise ValueError("Only recalculated nodes may be approved.")
        return self.review_store.record(self.project_id,node_id,"APPROVED",reviewer,comment)
