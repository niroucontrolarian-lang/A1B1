
from dataclasses import dataclass
@dataclass
class ProposedChange:
    object_id:str
    property_key:str
    old_value:object
    new_value:object
    reason:str
@dataclass
class ChangePreview:
    change:ProposedChange
    impacted:set[str]
    requires_approval:bool=True

def preview_change(change,engine):
    return ChangePreview(change,engine.impacted({change.object_id}),True)
