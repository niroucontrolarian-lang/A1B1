
from __future__ import annotations
from dataclasses import dataclass
from collections import defaultdict

@dataclass
class BomLine:
    category: str
    description: str
    manufacturer: str|None
    model: str|None
    part_number: str|None
    quantity: float
    unit: str
    source_status: str

def generate_bom(objects):
    grouped={}
    for o in objects:
        a=o.get("attributes",{})
        def val(k,default=None):
            v=a.get(k,default)
            if isinstance(v,dict) and "value" in v: return v["value"]
            return v
        key=(o["object_type"],val("description",o.get("tag") or o["object_type"]),
             val("manufacturer"),val("model"),val("part_number"),val("unit","pcs"))
        if key not in grouped:
            source_ok=bool(val("manufacturer_source_ref")) if (val("manufacturer") or val("model") or val("part_number")) else True
            grouped[key]=BomLine(key[0],key[1],key[2],key[3],key[4],0,key[5],"VERIFIED_SOURCE" if source_ok else "SOURCE_REQUIRED")
        grouped[key].quantity += float(val("quantity",1))
    return sorted(grouped.values(),key=lambda x:(x.category,x.description))
