
from .quality_gates import evaluate_gate,GATES

DEFAULT_GATE_MAP={
 "DESIGN":["M-101"],
 "CALCULATION":["M-101.current","C-101"],
 "PROTECTION":["QF-101"],
 "CONFIGURATION":["VFD-101.settings"],
 "DRAWING":["SLD-01"],
 "MANUFACTURING":["BOM-01","MCC.thermal"],
 "FAT":["BOM-01","SLD-01","VFD-101.settings"],
 "SAT":["M-101.current","QF-101","VFD-101.settings"],
 "AS_BUILT":["SLD-01","BOM-01"]
}
def evaluate_project_gates(states,gate_map=None):
    gate_map=gate_map or DEFAULT_GATE_MAP
    status={x["node_id"]:x["status"] for x in states}
    out=[]
    for gate in GATES:
        req={nid:status.get(nid,"INCOMPLETE") for nid in gate_map.get(gate,[])}
        r=evaluate_gate(gate,req)
        out.append({"gate":r.gate,"status":r.status,"blockers":r.blockers,"warnings":r.warnings})
    return out
