
from __future__ import annotations
from dataclasses import dataclass,field
from typing import Callable,Any
import hashlib,json

OUTDATED="OUTDATED"

@dataclass
class CalcNode:
    id:str
    depends_on:set[str]=field(default_factory=set)
    runner:Callable[[dict],Any]|None=None
    status:str="DRAFT"
    input_hash:str|None=None
    result:Any=None

def stable_hash(value)->str:
    raw=json.dumps(value,sort_keys=True,default=str,separators=(",",":")).encode()
    return hashlib.sha256(raw).hexdigest()

class RecalculationEngine:
    def __init__(self):
        self.nodes={}
        self.reverse={}
    def add(self,node:CalcNode):
        if node.id in self.nodes: raise ValueError("Duplicate calculation node.")
        self.nodes[node.id]=node
        for d in node.depends_on: self.reverse.setdefault(d,set()).add(node.id)
    def impacted(self,changed_ids:set[str]):
        seen=set(); stack=list(changed_ids)
        while stack:
            x=stack.pop()
            for y in self.reverse.get(x,set()):
                if y not in seen: seen.add(y); stack.append(y)
        return seen
    def mark_outdated(self,changed_ids:set[str]):
        imp=self.impacted(changed_ids)
        for x in imp: self.nodes[x].status=OUTDATED
        return imp
    def topological(self,subset:set[str]):
        order=[]; temp=set(); perm=set()
        def visit(x):
            if x in perm:return
            if x in temp:raise ValueError("Dependency cycle detected.")
            temp.add(x)
            for d in self.nodes[x].depends_on:
                if d in subset and d in self.nodes: visit(d)
            temp.remove(x);perm.add(x);order.append(x)
        for x in sorted(subset): visit(x)
        return order
    def recalculate(self,subset:set[str],context:dict):
        results={}
        for x in self.topological(subset):
            n=self.nodes[x]
            if n.runner is None:
                n.status="INCOMPLETE"; results[x]=None; continue
            depvals={d:(self.nodes[d].result if d in self.nodes else context.get(d)) for d in n.depends_on}
            h=stable_hash(depvals)
            n.result=n.runner(depvals); n.input_hash=h; n.status="CALCULATED"; results[x]=n.result
        return results
