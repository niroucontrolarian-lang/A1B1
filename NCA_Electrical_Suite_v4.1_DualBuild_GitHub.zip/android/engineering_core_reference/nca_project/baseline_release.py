
from dataclasses import dataclass,field
import datetime,uuid,hashlib,json

@dataclass
class ReleasedBaseline:
    id:str
    project_id:str
    code:str
    revision:str
    calculation_fingerprints:list[str]
    document_revisions:dict[str,str]
    equipment_source_versions:dict[str,str]
    released_by:str
    released_at:str
    fingerprint:str

def release_baseline(project_id,code,revision,calculation_fingerprints,document_revisions,
                     equipment_source_versions,released_by,release_decision):
    if not release_decision.allowed:
        raise ValueError("Baseline release blocked: "+"; ".join(release_decision.blockers))
    data={"project_id":project_id,"code":code,"revision":revision,
          "calculation_fingerprints":sorted(calculation_fingerprints),
          "document_revisions":document_revisions,"equipment_source_versions":equipment_source_versions}
    fp=hashlib.sha256(json.dumps(data,sort_keys=True).encode()).hexdigest()
    return ReleasedBaseline(str(uuid.uuid4()),project_id,code,revision,sorted(calculation_fingerprints),
        document_revisions,equipment_source_versions,released_by,
        datetime.datetime.now(datetime.timezone.utc).isoformat(),fp)
