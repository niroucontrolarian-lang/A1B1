
from dataclasses import dataclass,field

@dataclass
class ImpactItem:
    target_id:str
    category:str
    action:str
    reason:str

CATEGORY_MAP={
 "calculation":"RECALCULATION_REQUIRED",
 "protection":"ENGINEER_REVIEW_REQUIRED",
 "setting":"ENGINEER_REVIEW_REQUIRED",
 "drawing":"DOCUMENT_UPDATE_REQUIRED",
 "bom":"DOCUMENT_UPDATE_REQUIRED",
 "panel":"REDESIGN_REVIEW_REQUIRED",
}

def build_impact_report(impacted_ids,metadata):
    out=[]
    for x in sorted(impacted_ids):
        cat=metadata.get(x,{}).get("category","calculation")
        out.append(ImpactItem(x,cat,CATEGORY_MAP.get(cat,"REVIEW_REQUIRED"),
                              metadata.get(x,{}).get("reason","Upstream engineering input changed.")))
    return out
