
from dataclasses import dataclass
from nca_project.recalculation import RecalculationEngine,CalcNode
from nca_project.project_health import summarize
from nca_project.quality_gates import evaluate_gate

@dataclass
class OrchestrationResult:
    impacted:set
    health:object
    calculation_gate:object

class ProjectOrchestrator:
    def __init__(self,persistent_state,project_id):
        self.ps=persistent_state; self.project_id=project_id
    def restore_engine(self,runners=None):
        runners=runners or {}; e=RecalculationEngine()
        rows=self.ps.load_nodes(self.project_id)
        deps={}
        for a,b in self.ps.edges(self.project_id): deps.setdefault(b,set()).add(a)
        for r in rows:
            n=CalcNode(r["node_id"],deps.get(r["node_id"],set()),runners.get(r["node_id"]),
                       r["status"],r["input_hash"],None)
            e.add(n)
        return e
    def engineering_change(self,changed_id):
        impacted=self.ps.mark_impacted_outdated(self.project_id,changed_id)
        rows=self.ps.load_nodes(self.project_id)
        statuses={r["node_id"]:r["status"] for r in rows}
        health=summarize(statuses)
        gate=evaluate_gate("CALCULATION",statuses)
        return OrchestrationResult(impacted,health,gate)
