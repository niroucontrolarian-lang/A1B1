
class RecalculateService:
    def __init__(self,persistent_state): self.ps=persistent_state
    def candidates(self,project_id):
        return [x for x in self.ps.load_nodes(project_id) if x["status"]=="OUTDATED"]
    def mark_recalculated(self,project_id,node_id):
        nodes={x["node_id"]:x for x in self.ps.load_nodes(project_id)}
        if node_id not in nodes: raise ValueError("Unknown calculation node.")
        n=nodes[node_id]
        self.ps.save_node(project_id,node_id,n["category"],"CALCULATED")
        return {"node_id":node_id,"status":"CALCULATED"}
