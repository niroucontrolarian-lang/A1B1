
from dataclasses import dataclass,field

GATES=("DESIGN","CALCULATION","PROTECTION","CONFIGURATION","DRAWING","MANUFACTURING","FAT","SAT","AS_BUILT")
@dataclass
class GateResult:
    gate:str
    status:str
    blockers:list[str]=field(default_factory=list)
    warnings:list[str]=field(default_factory=list)

def evaluate_gate(gate,required_statuses):
    if gate not in GATES: raise ValueError("Unknown quality gate.")
    blockers=[k for k,v in required_statuses.items() if v in ("FAIL","INCOMPLETE","SOURCE_REQUIRED","OUTDATED")]
    warnings=[k for k,v in required_statuses.items() if v=="WARNING"]
    return GateResult(gate,"BLOCKED" if blockers else ("WARNING" if warnings else "PASS"),blockers,warnings)
