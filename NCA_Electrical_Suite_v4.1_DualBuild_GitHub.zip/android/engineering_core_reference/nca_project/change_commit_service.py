
class ChangeCommitService:
    def __init__(self,workflow,persistent_state,project_id):
        self.workflow=workflow;self.ps=persistent_state;self.project_id=project_id
    def commit(self,change_id,changed_object_id):
        value,revision=self.workflow.commit(change_id)
        impacted=self.ps.mark_impacted_outdated(self.project_id,changed_object_id)
        return {"value":value,"revision":revision,"impacted":sorted(impacted)}
    def cancel(self,change_id):
        self.workflow.cancel(change_id);return {"status":"CANCELLED"}
