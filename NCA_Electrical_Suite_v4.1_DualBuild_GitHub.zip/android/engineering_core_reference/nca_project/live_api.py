
from __future__ import annotations
from dataclasses import dataclass,asdict
from math import sqrt
from nca_calculations.evidence import Assumption,create_snapshot

@dataclass
class MotorInput:
    tag:str
    power_kw:float
    voltage_v:float
    efficiency:float
    power_factor:float

def calculate_motor(project_id:str,m:MotorInput):
    errors=[]
    if m.power_kw<=0: errors.append("Power must be > 0.")
    if m.voltage_v<=0: errors.append("Voltage must be > 0.")
    if not 0<m.efficiency<=1: errors.append("Efficiency must be in (0,1].")
    if not 0<m.power_factor<=1: errors.append("Power factor must be in (0,1].")
    if errors:return {"status":"FAIL","errors":errors}
    den=sqrt(3)*m.voltage_v*m.efficiency*m.power_factor
    current=m.power_kw*1000/den
    snap=create_snapshot("motor.flc","1.2.0",project_id,m.tag,
      {"power_kw":m.power_kw,"voltage_v":m.voltage_v,"efficiency":m.efficiency,"power_factor":m.power_factor},
      [],"I = P / (sqrt(3) × V × η × PF)",None,
      {"denominator":den},{"current_a":current},"CALCULATED",[])
    return {"status":"CALCULATED","current_a":current,"snapshot":asdict(snap)}

def why_motor(result):
    if result.get("status")!="CALCULATED":return result
    s=result["snapshot"]
    return {"calculation_id":s["calculation_id"],"engine_version":s["engine_version"],
      "inputs":s["inputs"],"method":s["method"],"intermediates":s["intermediates"],
      "outputs":s["outputs"],"warnings":s["warnings"],"fingerprint":s["fingerprint"]}
