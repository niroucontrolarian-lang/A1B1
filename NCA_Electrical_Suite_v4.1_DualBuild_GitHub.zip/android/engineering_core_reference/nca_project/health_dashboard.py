
from dataclasses import dataclass
BLOCKING={"FAIL","INCOMPLETE","SOURCE_REQUIRED","OUTDATED","BLOCKED"}
@dataclass
class HealthWidget:
    status:str
    total:int
    blockers:int
    by_status:dict
def build_health(states):
    by={}
    for s in states:
        st=s["status"];by[st]=by.get(st,0)+1
    n=sum(v for k,v in by.items() if k in BLOCKING)
    return HealthWidget("ATTENTION_REQUIRED" if n else "HEALTHY",len(states),n,by)
