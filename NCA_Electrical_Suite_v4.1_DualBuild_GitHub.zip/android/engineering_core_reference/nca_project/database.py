
from __future__ import annotations
import sqlite3, json, uuid, datetime
from pathlib import Path

SCHEMA_VERSION=3
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def uid(): return str(uuid.uuid4())

SCHEMA = """
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS workspace(
 id TEXT PRIMARY KEY, display_name TEXT NOT NULL, created_at TEXT NOT NULL, modified_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS project(
 id TEXT PRIMARY KEY, workspace_id TEXT NOT NULL, project_no TEXT, name TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'DRAFT', active_baseline_id TEXT, created_at TEXT NOT NULL, modified_at TEXT NOT NULL,
 FOREIGN KEY(workspace_id) REFERENCES workspace(id)
);
CREATE TABLE IF NOT EXISTS engineering_object(
 id TEXT PRIMARY KEY, project_id TEXT NOT NULL, parent_id TEXT, object_type TEXT NOT NULL, tag TEXT,
 status TEXT NOT NULL DEFAULT 'DRAFT', revision INTEGER NOT NULL DEFAULT 0,
 attributes_json TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL, modified_at TEXT NOT NULL,
 FOREIGN KEY(project_id) REFERENCES project(id)
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_project_tag ON engineering_object(project_id,tag) WHERE tag IS NOT NULL;
CREATE TABLE IF NOT EXISTS baseline(
 id TEXT PRIMARY KEY, project_id TEXT NOT NULL, code TEXT NOT NULL, title TEXT,
 status TEXT NOT NULL DEFAULT 'DRAFT', parent_id TEXT, created_at TEXT NOT NULL,
 FOREIGN KEY(project_id) REFERENCES project(id)
);
CREATE TABLE IF NOT EXISTS change_set(
 id TEXT PRIMARY KEY, project_id TEXT NOT NULL, baseline_id TEXT, title TEXT NOT NULL, reason TEXT,
 author_user_id TEXT, status TEXT NOT NULL DEFAULT 'OPEN', created_at TEXT NOT NULL, committed_at TEXT,
 FOREIGN KEY(project_id) REFERENCES project(id)
);
CREATE TABLE IF NOT EXISTS change_item(
 id TEXT PRIMARY KEY, change_set_id TEXT NOT NULL, object_id TEXT NOT NULL, property_key TEXT NOT NULL,
 old_json TEXT, new_json TEXT, impact_json TEXT NOT NULL DEFAULT '[]',
 FOREIGN KEY(change_set_id) REFERENCES change_set(id)
);
CREATE TABLE IF NOT EXISTS audit_log(
 id TEXT PRIMARY KEY, project_id TEXT, actor_user_id TEXT, event_type TEXT NOT NULL,
 target_type TEXT, target_id TEXT, payload_json TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL
);
"""

class NcaDatabase:
    def __init__(self,path):
        self.path=Path(path)
        self.con=sqlite3.connect(self.path)
        self.con.row_factory=sqlite3.Row
        self.con.execute("PRAGMA foreign_keys=ON")
    def initialize(self,display_name="NCA Engineering Database"):
        self.con.executescript(SCHEMA)
        self.con.execute("INSERT OR REPLACE INTO meta(key,value) VALUES('schema_version',?)",(str(SCHEMA_VERSION),))
        row=self.con.execute("SELECT id FROM workspace LIMIT 1").fetchone()
        if not row:
            wid=uid(); t=now()
            self.con.execute("INSERT INTO workspace VALUES(?,?,?,?)",(wid,display_name,t,t))
        self.con.commit()
    def workspace(self):
        return dict(self.con.execute("SELECT * FROM workspace LIMIT 1").fetchone())
    def rename_workspace(self,name):
        if not name.strip(): raise ValueError("Workspace display name cannot be empty.")
        self.con.execute("UPDATE workspace SET display_name=?,modified_at=?",(name.strip(),now())); self.con.commit()
    def create_project(self,name,project_no=None):
        wid=self.workspace()["id"]; pid=uid(); t=now()
        self.con.execute("INSERT INTO project(id,workspace_id,project_no,name,created_at,modified_at) VALUES(?,?,?,?,?,?)",
                         (pid,wid,project_no,name,t,t)); self.con.commit(); return pid
    def list_projects(self):
        return [dict(r) for r in self.con.execute("SELECT * FROM project ORDER BY modified_at DESC")]
    def add_object(self,project_id,object_type,tag=None,parent_id=None,attributes=None):
        oid=uid(); t=now()
        self.con.execute("""INSERT INTO engineering_object
        (id,project_id,parent_id,object_type,tag,attributes_json,created_at,modified_at)
        VALUES(?,?,?,?,?,?,?,?)""",(oid,project_id,parent_id,object_type,tag,json.dumps(attributes or {},ensure_ascii=False),t,t))
        self.con.commit(); return oid
    def objects(self,project_id):
        out=[]
        for r in self.con.execute("SELECT * FROM engineering_object WHERE project_id=? ORDER BY object_type,tag",(project_id,)):
            d=dict(r); d["attributes"]=json.loads(d.pop("attributes_json")); out.append(d)
        return out
    def create_baseline(self,project_id,code,title="",parent_id=None):
        bid=uid()
        self.con.execute("INSERT INTO baseline(id,project_id,code,title,parent_id,created_at) VALUES(?,?,?,?,?,?)",
                         (bid,project_id,code,title,parent_id,now())); self.con.commit(); return bid
    def set_active_baseline(self,project_id,baseline_id):
        self.con.execute("UPDATE project SET active_baseline_id=?,modified_at=? WHERE id=?",(baseline_id,now(),project_id)); self.con.commit()
    def create_change_set(self,project_id,title,reason="",baseline_id=None,author_user_id=None):
        cid=uid()
        self.con.execute("""INSERT INTO change_set(id,project_id,baseline_id,title,reason,author_user_id,created_at)
        VALUES(?,?,?,?,?,?,?)""",(cid,project_id,baseline_id,title,reason,author_user_id,now())); self.con.commit(); return cid
    def add_change(self,change_set_id,object_id,key,old,new,impacts=None):
        iid=uid()
        self.con.execute("""INSERT INTO change_item(id,change_set_id,object_id,property_key,old_json,new_json,impact_json)
        VALUES(?,?,?,?,?,?,?)""",(iid,change_set_id,object_id,key,json.dumps(old),json.dumps(new),
                                 json.dumps(impacts or []))); self.con.commit(); return iid
    def close(self): self.con.close()
