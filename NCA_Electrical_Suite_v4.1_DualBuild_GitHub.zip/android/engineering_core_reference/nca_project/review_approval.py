
import datetime,uuid
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
class ReviewApproval:
    def __init__(self,con):
        self.con=con
        self.con.execute("""CREATE TABLE IF NOT EXISTS engineering_review(
          id TEXT PRIMARY KEY,project_id TEXT NOT NULL,node_id TEXT NOT NULL,action TEXT NOT NULL,
          reviewer TEXT NOT NULL,comment TEXT,created_at TEXT NOT NULL)""")
        self.con.commit()
    def record(self,project_id,node_id,action,reviewer,comment=""):
        if action not in {"REVIEWED","APPROVED","REJECTED"}: raise ValueError("Invalid review action.")
        rid=str(uuid.uuid4())
        self.con.execute("INSERT INTO engineering_review VALUES(?,?,?,?,?,?,?)",
          (rid,project_id,node_id,action,reviewer,comment,now()));self.con.commit()
        return {"id":rid,"project_id":project_id,"node_id":node_id,"action":action,"reviewer":reviewer,"comment":comment}
    def history(self,project_id,node_id=None):
        if node_id:
            rows=self.con.execute("""SELECT id,node_id,action,reviewer,comment,created_at FROM engineering_review
              WHERE project_id=? AND node_id=? ORDER BY created_at DESC""",(project_id,node_id)).fetchall()
        else:
            rows=self.con.execute("""SELECT id,node_id,action,reviewer,comment,created_at FROM engineering_review
              WHERE project_id=? ORDER BY created_at DESC""",(project_id,)).fetchall()
        keys=("id","node_id","action","reviewer","comment","created_at")
        return [dict(zip(keys,r)) for r in rows]
