
from __future__ import annotations
import sqlite3,json,datetime,hashlib
from dataclasses import dataclass

def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def dumps(x): return json.dumps(x,ensure_ascii=False,sort_keys=True,default=str)
def loads(x): return json.loads(x) if x else None

SCHEMA="""
CREATE TABLE IF NOT EXISTS calc_state(
 project_id TEXT NOT NULL,node_id TEXT NOT NULL,category TEXT NOT NULL,status TEXT NOT NULL,
 input_hash TEXT,result_json TEXT,engine_version TEXT,schema_version INTEGER,
 updated_at TEXT NOT NULL,PRIMARY KEY(project_id,node_id)
);
CREATE TABLE IF NOT EXISTS dependency_edge(
 project_id TEXT NOT NULL,upstream_id TEXT NOT NULL,downstream_id TEXT NOT NULL,
 PRIMARY KEY(project_id,upstream_id,downstream_id)
);
CREATE TABLE IF NOT EXISTS release_snapshot(
 id TEXT PRIMARY KEY,project_id TEXT NOT NULL,baseline_code TEXT NOT NULL,
 health_json TEXT NOT NULL,gate_json TEXT NOT NULL,created_at TEXT NOT NULL
);
"""
class PersistentState:
    def __init__(self,con):
        self.con=con; self.con.executescript(SCHEMA); self.con.commit()
    def save_node(self,project_id,node_id,category,status,input_hash=None,result=None,
                  engine_version="0.9.0",schema_version=9):
        self.con.execute("""INSERT OR REPLACE INTO calc_state VALUES(?,?,?,?,?,?,?,?,?)""",
          (project_id,node_id,category,status,input_hash,dumps(result) if result is not None else None,
           engine_version,schema_version,now())); self.con.commit()
    def load_nodes(self,project_id):
        rows=self.con.execute("SELECT * FROM calc_state WHERE project_id=?",(project_id,)).fetchall()
        cols=[x[0] for x in self.con.execute("SELECT * FROM calc_state LIMIT 0").description]
        return [dict(zip(cols,r)) for r in rows]
    def save_edge(self,project_id,upstream,downstream):
        self.con.execute("INSERT OR IGNORE INTO dependency_edge VALUES(?,?,?)",(project_id,upstream,downstream));self.con.commit()
    def edges(self,project_id):
        return self.con.execute("SELECT upstream_id,downstream_id FROM dependency_edge WHERE project_id=?",(project_id,)).fetchall()
    def mark_impacted_outdated(self,project_id,changed_id):
        edges=self.edges(project_id); rev={}
        for a,b in edges: rev.setdefault(a,set()).add(b)
        seen=set(); stack=[changed_id]
        while stack:
            x=stack.pop()
            for y in rev.get(x,set()):
                if y not in seen: seen.add(y);stack.append(y)
        if seen:
            q="UPDATE calc_state SET status='OUTDATED',updated_at=? WHERE project_id=? AND node_id IN (%s)"%(",".join("?"*len(seen)))
            self.con.execute(q,(now(),project_id,*seen));self.con.commit()
        return seen
