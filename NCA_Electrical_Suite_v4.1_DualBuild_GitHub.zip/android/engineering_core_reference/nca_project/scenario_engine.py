
from dataclasses import dataclass
from nca_project.scenarios import validate_scenario

@dataclass
class ScenarioResult:
    scenario_id:str
    status:str
    active_sources:list[str]
    outputs:dict
    warnings:list[str]

def execute_scenario(scenario,source_models,network_factory):
    issues=validate_scenario(scenario)
    if issues:return ScenarioResult(scenario.id,"FAIL",sorted(scenario.active_sources),{},issues)
    missing=[x for x in scenario.active_sources if x not in source_models]
    if missing:return ScenarioResult(scenario.id,"INCOMPLETE",sorted(scenario.active_sources),{},
        ["Missing source model: "+x for x in missing])
    if len(scenario.active_sources)!=1:
        return ScenarioResult(scenario.id,"INCOMPLETE",sorted(scenario.active_sources),{},
          ["v1.0 scenario executor supports one active source at a time; parallel-source studies require a later network solver."])
    sid=next(iter(scenario.active_sources)); net=network_factory(source_models[sid])
    return ScenarioResult(scenario.id,"CALCULATED",[sid],{"network":net},[])
