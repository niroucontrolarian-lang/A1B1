
from dataclasses import dataclass,asdict
import json,uuid,datetime
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()

@dataclass
class EngineeringChange:
    id:str; project_id:str; object_id:str; property_key:str
    old_value:object; new_value:object; reason:str; status:str="PROPOSED"

class ChangeWorkflow:
    def __init__(self,con):
        self.con=con
        self.con.execute("""CREATE TABLE IF NOT EXISTS engineering_change(
          id TEXT PRIMARY KEY,project_id TEXT NOT NULL,object_id TEXT NOT NULL,property_key TEXT NOT NULL,
          old_json TEXT,new_json TEXT,reason TEXT NOT NULL,status TEXT NOT NULL,created_at TEXT NOT NULL,committed_at TEXT)""")
        self.con.execute("""CREATE TABLE IF NOT EXISTS live_object_value(
          project_id TEXT NOT NULL,object_id TEXT NOT NULL,property_key TEXT NOT NULL,value_json TEXT NOT NULL,
          revision INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(project_id,object_id,property_key))""")
        self.con.commit()
    def seed(self,p,o,k,v):
        self.con.execute("INSERT OR IGNORE INTO live_object_value VALUES(?,?,?,?,0)",(p,o,k,json.dumps(v)));self.con.commit()
    def value(self,p,o,k):
        r=self.con.execute("SELECT value_json,revision FROM live_object_value WHERE project_id=? AND object_id=? AND property_key=?",(p,o,k)).fetchone()
        return (json.loads(r[0]),r[1]) if r else (None,None)
    def propose(self,p,o,k,new,reason):
        old,_=self.value(p,o,k); c=EngineeringChange(str(uuid.uuid4()),p,o,k,old,new,reason)
        self.con.execute("INSERT INTO engineering_change VALUES(?,?,?,?,?,?,?,?,?,?)",
          (c.id,p,o,k,json.dumps(old),json.dumps(new),reason,c.status,now(),None));self.con.commit();return c
    def cancel(self,cid):
        self.con.execute("UPDATE engineering_change SET status='CANCELLED' WHERE id=? AND status='PROPOSED'",(cid,));self.con.commit()
    def commit(self,cid):
        r=self.con.execute("SELECT project_id,object_id,property_key,new_json,status FROM engineering_change WHERE id=?",(cid,)).fetchone()
        if not r or r[4]!="PROPOSED": raise ValueError("Change is not committable.")
        p,o,k,n,_=r
        self.con.execute("""UPDATE live_object_value SET value_json=?,revision=revision+1
          WHERE project_id=? AND object_id=? AND property_key=?""",(n,p,o,k))
        self.con.execute("UPDATE engineering_change SET status='COMMITTED',committed_at=? WHERE id=?",(now(),cid));self.con.commit()
        return self.value(p,o,k)
