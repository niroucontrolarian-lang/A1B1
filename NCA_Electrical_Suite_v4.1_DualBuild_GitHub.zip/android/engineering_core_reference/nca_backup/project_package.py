
from __future__ import annotations
from pathlib import Path
import zipfile, hashlib, json, shutil, tempfile, datetime

def sha256(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""): h.update(b)
    return h.hexdigest()

def export_ncaproj(database_path,output_path,attachments=None):
    database_path=Path(database_path); output_path=Path(output_path)
    files=[database_path]+[Path(x) for x in (attachments or [])]
    manifest={"format":"NCAPROJ","format_version":1,
              "created_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "files":[]}
    with zipfile.ZipFile(output_path,"w",zipfile.ZIP_DEFLATED) as z:
        for f in files:
            arc=("database/" if f==database_path else "attachments/")+f.name
            z.write(f,arc)
            manifest["files"].append({"path":arc,"sha256":sha256(f),"size":f.stat().st_size})
        z.writestr("manifest.json",json.dumps(manifest,indent=2))
    return manifest

def verify_ncaproj(package_path):
    with zipfile.ZipFile(package_path) as z:
        m=json.loads(z.read("manifest.json"))
        problems=[]
        for x in m["files"]:
            data=z.read(x["path"])
            digest=hashlib.sha256(data).hexdigest()
            if digest!=x["sha256"]: problems.append(x["path"])
        return {"valid":not problems,"problems":problems,"manifest":m}
