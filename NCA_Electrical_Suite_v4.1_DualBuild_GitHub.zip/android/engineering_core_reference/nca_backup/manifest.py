from __future__ import annotations
from dataclasses import dataclass, asdict, field
from pathlib import Path
from hashlib import sha256
import json, datetime

@dataclass
class BackupManifest:
    database_uuid: str
    schema_version: int
    project_ids: list[str]
    engine_versions: dict[str,str]
    files: dict[str,str] = field(default_factory=dict)
    created_at: str = field(default_factory=lambda: datetime.datetime.now(datetime.timezone.utc).isoformat())

def hash_file(path: Path) -> str:
    h=sha256()
    with path.open("rb") as f:
        for block in iter(lambda:f.read(1024*1024), b""): h.update(block)
    return h.hexdigest()

def write_manifest(manifest: BackupManifest, path: Path):
    path.write_text(json.dumps(asdict(manifest),ensure_ascii=False,indent=2),encoding="utf-8")
