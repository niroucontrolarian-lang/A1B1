
from html import escape
def motor_report_html(company,project,snapshot):
    i=snapshot["inputs"];o=snapshot["outputs"]
    rows="".join(f"<tr><td>{escape(str(k))}</td><td>{escape(str(v))}</td></tr>" for k,v in i.items())
    return f"""<!doctype html><html><meta charset='utf-8'><body style='font-family:Arial'>
    <h1>{escape(company)}</h1><h2>Motor Calculation Report</h2>
    <p>Project: {escape(project)} | Calculation: {escape(snapshot['calculation_id'])}</p>
    <h3>Inputs</h3><table border='1' cellspacing='0' cellpadding='6'>{rows}</table>
    <h3>Method</h3><p>{escape(snapshot['method'])}</p>
    <h3>Result</h3><p>Current = {o['current_a']:.2f} A</p>
    <p>Status: {escape(snapshot['status'])}</p>
    <p>Engine: {escape(snapshot['engine_version'])}</p>
    <p>Evidence fingerprint: {escape(snapshot['fingerprint'])}</p>
    <hr><p>Engineering result requires review against project inputs, equipment data and applicable standards.</p>
    </body></html>"""
