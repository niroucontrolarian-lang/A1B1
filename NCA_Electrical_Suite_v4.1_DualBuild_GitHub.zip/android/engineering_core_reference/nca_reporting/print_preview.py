
from dataclasses import dataclass
@dataclass
class PrintOptions:
    paper:str="A4"
    orientation:str="portrait"
    include_evidence:bool=True
    include_warnings:bool=True
    company_name:str="Niroo Control Arian (NCA)"
    prepared_by:str="Habib Shahbazi"

def validate_print_options(o):
    if o.paper not in {"A4","A3"}: raise ValueError("Unsupported paper size.")
    if o.orientation not in {"portrait","landscape"}: raise ValueError("Unsupported orientation.")
    return o
