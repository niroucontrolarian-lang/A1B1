
from dataclasses import dataclass
SUPPORTED_LANGUAGES=("fa","en","fr","ar","es")
@dataclass
class ReportOptions:
    language:str="en"
    paper:str="A4"
    orientation:str="portrait"
    company_name:str="Niroo Control Arian (NCA)"
    prepared_by:str="Habib Shahbazi"
def validate(o):
    if o.language not in SUPPORTED_LANGUAGES: raise ValueError("Unsupported report language.")
    if o.paper not in {"A4","A3"}: raise ValueError("Unsupported paper.")
    if o.orientation not in {"portrait","landscape"}: raise ValueError("Unsupported orientation.")
    return o
