
LANGUAGES={
 "fa":{"name":"فارسی","dir":"rtl"},
 "en":{"name":"English","dir":"ltr"},
 "fr":{"name":"Français","dir":"ltr"},
 "ar":{"name":"العربية","dir":"rtl"},
 "es":{"name":"Español","dir":"ltr"},
}
T={
"fa":{"title":"گزارش محاسبات مهندسی برق","project":"پروژه","inputs":"ورودی‌ها","input":"پارامتر","value":"مقدار",
"method":"روش محاسبه","result":"نتیجه","motor_current":"جریان موتور","status":"وضعیت","engine":"نسخه موتور محاسبات",
"trace":"ردیابی محاسبات","fingerprint":"شناسه شواهد","warning":"هشدارها","prepared":"تهیه‌کننده","review":"نیازمند بازبینی مهندسی"},
"en":{"title":"Electrical Engineering Calculation Report","project":"Project","inputs":"Inputs","input":"Input","value":"Value",
"method":"Method","result":"Result","motor_current":"Motor current","status":"Status","engine":"Calculation Engine",
"trace":"Traceability","fingerprint":"Evidence fingerprint","warning":"Warnings","prepared":"Prepared by","review":"Engineering review required"},
"fr":{"title":"Rapport de calcul d'ingénierie électrique","project":"Projet","inputs":"Données d'entrée","input":"Paramètre","value":"Valeur",
"method":"Méthode","result":"Résultat","motor_current":"Courant moteur","status":"État","engine":"Moteur de calcul",
"trace":"Traçabilité","fingerprint":"Empreinte de preuve","warning":"Avertissements","prepared":"Préparé par","review":"Revue d'ingénierie requise"},
"ar":{"title":"تقرير الحسابات الهندسية الكهربائية","project":"المشروع","inputs":"المدخلات","input":"المعامل","value":"القيمة",
"method":"طريقة الحساب","result":"النتيجة","motor_current":"تيار المحرك","status":"الحالة","engine":"إصدار محرك الحساب",
"trace":"تتبّع الحساب","fingerprint":"بصمة الدليل","warning":"التحذيرات","prepared":"إعداد","review":"يتطلب مراجعة هندسية"},
"es":{"title":"Informe de cálculos de ingeniería eléctrica","project":"Proyecto","inputs":"Entradas","input":"Parámetro","value":"Valor",
"method":"Método","result":"Resultado","motor_current":"Corriente del motor","status":"Estado","engine":"Motor de cálculo",
"trace":"Trazabilidad","fingerprint":"Huella de evidencia","warning":"Advertencias","prepared":"Preparado por","review":"Requiere revisión de ingeniería"},
}
def tr(lang,key):
    if lang not in T: raise ValueError("Unsupported report language.")
    return T[lang][key]
def direction(lang): return LANGUAGES[lang]["dir"]
