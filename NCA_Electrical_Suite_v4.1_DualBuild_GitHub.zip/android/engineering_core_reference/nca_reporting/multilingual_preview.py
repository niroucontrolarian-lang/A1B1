
from html import escape
from .i18n import tr,direction
def motor_preview_html(snapshot,project,options):
    l=options.language; d=direction(l); align="right" if d=="rtl" else "left"
    rows="".join(f"<tr><td>{escape(str(k))}</td><td>{escape(str(v))}</td></tr>" for k,v in snapshot["inputs"].items())
    warnings="<br>".join(escape(x) for x in snapshot.get("warnings",[])) or "-"
    return f"""<!doctype html><html lang="{l}" dir="{d}"><head><meta charset="utf-8"><style>
    @page{{size:{options.paper} {options.orientation};margin:15mm}}body{{font-family:Arial,sans-serif;direction:{d};text-align:{align};color:#17202a}}
    header{{border-bottom:3px solid #2563eb;padding-bottom:8px}}table{{border-collapse:collapse;width:100%}}td,th{{border:1px solid #aaa;padding:7px}}
    th{{background:#e8eef7}}.meta{{color:#555}}.evidence{{direction:ltr;text-align:left;font-family:monospace;font-size:10px}}</style></head><body>
    <header><b>{escape(options.company_name)}</b><h1>{tr(l,'title')}</h1></header>
    <p class="meta">{tr(l,'project')}: {escape(project)} | {tr(l,'prepared')}: {escape(options.prepared_by)}</p>
    <h2>{tr(l,'inputs')}</h2><table><tr><th>{tr(l,'input')}</th><th>{tr(l,'value')}</th></tr>{rows}</table>
    <h2>{tr(l,'method')}</h2><p dir="ltr">{escape(snapshot['method'])}</p>
    <h2>{tr(l,'result')}</h2><p>{tr(l,'motor_current')}: {snapshot['outputs']['current_a']:.2f} A</p>
    <p>{tr(l,'status')}: {escape(snapshot['status'])}</p><p>{tr(l,'engine')}: {escape(snapshot['engine_version'])}</p>
    <h2>{tr(l,'warning')}</h2><p>{warnings}</p><h2>{tr(l,'trace')}</h2>
    <p class="evidence">{tr(l,'fingerprint')}: {escape(snapshot['fingerprint'])}</p><hr><b>{tr(l,'review')}</b>
    </body></html>"""
