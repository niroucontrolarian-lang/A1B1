
from pathlib import Path
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.lib.pagesizes import A4,A3,landscape
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.enums import TA_LEFT,TA_RIGHT
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle
from reportlab.lib.units import mm
from .i18n import tr,direction
from .report_options import validate

# Built-in Unicode CID font required for Arabic/Persian text in this runtime.
CID_FONT="HYSMyeongJo-Medium"
try:
    pdfmetrics.registerFont(UnicodeCIDFont(CID_FONT))
except Exception:
    pass

def _rtl_visual(text):
    # Prefer proper shaping/bidi when installed. Fallback preserves Unicode text
    # and direction but is marked by rtl_engine_status() as limited.
    try:
        import arabic_reshaper
        from bidi.algorithm import get_display
        return get_display(arabic_reshaper.reshape(str(text)))
    except Exception:
        return str(text)

def rtl_engine_status():
    try:
        import arabic_reshaper
        from bidi.algorithm import get_display
        return "SHAPING_AVAILABLE"
    except Exception:
        return "UNICODE_CID_FALLBACK"

def build_multilingual_motor_pdf(path,snapshot,project,options):
    validate(options); lang=options.language; rtl=direction(lang)=="rtl"
    page=A4 if options.paper=="A4" else A3
    if options.orientation=="landscape": page=landscape(page)
    font=CID_FONT if rtl else "Helvetica"
    bold=CID_FONT if rtl else "Helvetica-Bold"
    align=TA_RIGHT if rtl else TA_LEFT
    def tx(x): return _rtl_visual(x) if rtl else str(x)
    doc=SimpleDocTemplate(str(path),pagesize=page,rightMargin=15*mm,leftMargin=15*mm,topMargin=15*mm,bottomMargin=15*mm)
    normal=ParagraphStyle("n",fontName=font,fontSize=10,leading=15,alignment=align)
    heading=ParagraphStyle("h",fontName=bold,fontSize=14,leading=19,alignment=align,spaceBefore=6)
    title=ParagraphStyle("t",fontName=bold,fontSize=18,leading=24,alignment=align)
    story=[Paragraph(tx(options.company_name),title),Paragraph(tx(tr(lang,"title")),heading),
           Paragraph(tx(f"{tr(lang,'project')}: {project}"),normal),
           Paragraph(tx(f"{tr(lang,'prepared')}: {options.prepared_by}"),normal),Spacer(1,5*mm)]
    data=[[tx(tr(lang,"input")),tx(tr(lang,"value"))]]
    for k,v in snapshot["inputs"].items(): data.append([tx(k),tx(v)])
    tab=Table(data,colWidths=[70*mm,75*mm],hAlign="RIGHT" if rtl else "LEFT")
    tab.setStyle(TableStyle([("FONTNAME",(0,0),(-1,-1),font),("BACKGROUND",(0,0),(-1,0),colors.HexColor("#E8EEF7")),
      ("GRID",(0,0),(-1,-1),0.4,colors.grey),("ALIGN",(0,0),(-1,-1),"RIGHT" if rtl else "LEFT"),("PADDING",(0,0),(-1,-1),6)]))
    story += [Paragraph(tx(tr(lang,"inputs")),heading),tab,
      Paragraph(tx(tr(lang,"method")),heading),Paragraph(snapshot["method"],normal),
      Paragraph(tx(tr(lang,"result")),heading),
      Paragraph(tx(f"{tr(lang,'motor_current')}: {snapshot['outputs']['current_a']:.2f} A"),normal),
      Paragraph(tx(f"{tr(lang,'status')}: {snapshot['status']}"),normal),
      Paragraph(tx(f"{tr(lang,'engine')}: {snapshot['engine_version']}"),normal),
      Paragraph(tx(tr(lang,"trace")),heading),
      Paragraph(f"{tr(lang,'fingerprint')}: {snapshot['fingerprint']}",ParagraphStyle("ev",parent=normal,alignment=TA_LEFT,fontName=font,fontSize=8))]
    if snapshot.get("warnings"):
        story += [Paragraph(tx(tr(lang,"warning")),heading),Paragraph(tx(" | ".join(snapshot["warnings"])),normal)]
    story += [Spacer(1,6*mm),Paragraph(tx(tr(lang,"review")),normal)]
    doc.build(story)
    return {"path":str(path),"language":lang,"direction":"rtl" if rtl else "ltr","rtl_engine":rtl_engine_status() if rtl else "N/A"}
