
from reportlab.lib.pagesizes import A4,A3,landscape
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak
from reportlab.lib.units import mm

def build_motor_pdf(path,snapshot,project_name="NCA Engineering Project",paper="A4",orientation="portrait"):
    page=A4 if paper=="A4" else A3
    if orientation=="landscape": page=landscape(page)
    doc=SimpleDocTemplate(str(path),pagesize=page,rightMargin=15*mm,leftMargin=15*mm,topMargin=15*mm,bottomMargin=15*mm)
    ss=getSampleStyleSheet(); title=ParagraphStyle("ncaTitle",parent=ss["Title"],fontName="Helvetica-Bold",fontSize=18,leading=22)
    h=ParagraphStyle("ncaH",parent=ss["Heading2"],fontName="Helvetica-Bold")
    normal=ParagraphStyle("ncaN",parent=ss["BodyText"],fontName="Helvetica",leading=14)
    story=[Paragraph("Niroo Control Arian (NCA)",title),Paragraph("Electrical Engineering Calculation Report",h),
           Paragraph(f"Project: {project_name}",normal),Spacer(1,6*mm)]
    inp=snapshot["inputs"]
    data=[["Input","Value"]]+[[str(k),str(v)] for k,v in inp.items()]
    t=Table(data,colWidths=[65*mm,80*mm]);t.setStyle(TableStyle([
      ("BACKGROUND",(0,0),(-1,0),colors.HexColor("#E8EEF7")),("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),
      ("GRID",(0,0),(-1,-1),0.4,colors.grey),("PADDING",(0,0),(-1,-1),6)]))
    story += [Paragraph("Inputs",h),t,Spacer(1,5*mm),
      Paragraph("Method",h),Paragraph(snapshot["method"],normal),Spacer(1,4*mm),
      Paragraph("Result",h),Paragraph(f"Motor current: {snapshot['outputs']['current_a']:.2f} A",normal),
      Paragraph(f"Status: {snapshot['status']}",normal),Paragraph(f"Calculation Engine: {snapshot['engine_version']}",normal),
      Spacer(1,4*mm),Paragraph("Traceability",h),Paragraph(f"Evidence fingerprint: {snapshot['fingerprint']}",normal)]
    if snapshot.get("warnings"):
      story += [Paragraph("Warnings",h),Paragraph("<br/>".join(snapshot["warnings"]),normal)]
    story += [Spacer(1,8*mm),Paragraph("Prepared for engineering review. Final equipment selection and settings require verified project and manufacturer data.",normal)]
    doc.build(story); return str(path)
