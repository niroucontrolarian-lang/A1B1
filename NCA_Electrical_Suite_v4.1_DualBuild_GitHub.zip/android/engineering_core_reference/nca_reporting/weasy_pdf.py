from pathlib import Path
from weasyprint import HTML
from .multilingual_preview import motor_preview_html

FONT_STACK_RTL = "'Noto Sans Arabic','Noto Sans',sans-serif"
FONT_STACK_LTR = "'Noto Sans','DejaVu Sans',sans-serif"

def _inject_print_css(html, rtl):
    font = FONT_STACK_RTL if rtl else FONT_STACK_LTR
    extra = f"""<style>
    body{{font-family:{font};font-size:10.5pt;line-height:1.55}}
    h1{{font-size:20pt;margin:5mm 0 3mm}} h2{{font-size:13pt;margin:5mm 0 2mm}}
    header{{display:flex;flex-direction:column;gap:2mm}}
    table{{page-break-inside:avoid}} .evidence{{word-break:break-all}}
    </style>"""
    return html.replace('</head>', extra+'</head>')

def build_weasy_motor_pdf(path, snapshot, project, options):
    html = motor_preview_html(snapshot, project, options)
    rtl = 'dir="rtl"' in html
    html = _inject_print_css(html, rtl)
    out = Path(path)
    out.parent.mkdir(parents=True, exist_ok=True)
    HTML(string=html, base_url=str(out.parent)).write_pdf(str(out))
    return {"path":str(out),"language":options.language,"direction":"rtl" if rtl else "ltr","renderer":"WEASYPRINT_PANGO"}
