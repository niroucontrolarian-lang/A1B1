
from pathlib import Path
from html import escape
from .i18n import tr,direction
from .report_options import validate

def _page_css(options,rtl):
    return f"""
    @page {{ size:{options.paper} {options.orientation}; margin:14mm;
      @bottom-center {{ content: "NCA | " counter(page) " / " counter(pages); font-size:8pt; color:#666; }}
    }}
    *{{box-sizing:border-box}} body{{font-family:Arial, sans-serif;direction:{'rtl' if rtl else 'ltr'};color:#1f2937;font-size:10pt}}
    .cover{{min-height:245mm;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;direction:ltr;width:100%}}
    .cover img{{display:block;max-width:75mm;max-height:38mm;margin:0 auto 10mm auto}}
    .cover h1{{width:100%;max-width:175mm;text-align:center;direction:{'rtl' if rtl else 'ltr'};unicode-bidi:plaintext;overflow-wrap:anywhere}}
    .cover h3{{width:100%;max-width:175mm;text-align:center;direction:ltr}}
    .cover .meta{{direction:{'rtl' if rtl else 'ltr'};width:100%;max-width:175mm}}
    h1{{font-size:22pt;margin:4mm 0}} h2{{font-size:14pt;border-bottom:2px solid #2563eb;padding-bottom:2mm}}
    .meta{{width:100%;border-collapse:collapse;margin:5mm 0}} .meta td{{border-bottom:1px solid #ddd;padding:3mm}}
    table.data{{width:100%;border-collapse:collapse}} table.data td,table.data th{{border:1px solid #aaa;padding:2.5mm}}
    table.data th{{background:#eaf0f8}} .ltr{{direction:ltr;text-align:left}} .pagebreak{{page-break-before:always}}
    .approval td{{height:18mm;vertical-align:top}} .status{{font-weight:bold}} .warn{{background:#fff7ed;border:1px solid #fdba74;padding:3mm}}
    """
def _labels(lang):
    extra={
      "fa":{"docno":"شماره سند","revision":"ویرایش","client":"کارفرما","approval":"تأیید و تصویب","role":"نقش","name":"نام","signature":"امضا","date":"تاریخ","scope":"دامنه گزارش","prepared_role":"تهیه‌کننده","checked_role":"بازبینی‌کننده","approved_role":"تأییدکننده"},
      "en":{"docno":"Document No.","revision":"Revision","client":"Client","approval":"Review & Approval","role":"Role","name":"Name","signature":"Signature","date":"Date","scope":"Report Scope","prepared_role":"Prepared","checked_role":"Checked","approved_role":"Approved"},
      "fr":{"docno":"N° document","revision":"Révision","client":"Client","approval":"Revue et approbation","role":"Rôle","name":"Nom","signature":"Signature","date":"Date","scope":"Périmètre du rapport","prepared_role":"Préparé par","checked_role":"Vérifié par","approved_role":"Approuvé par"},
      "ar":{"docno":"رقم المستند","revision":"المراجعة","client":"العميل","approval":"المراجعة والاعتماد","role":"الدور","name":"الاسم","signature":"التوقيع","date":"التاريخ","scope":"نطاق التقرير","prepared_role":"إعداد","checked_role":"مراجعة","approved_role":"اعتماد"},
      "es":{"docno":"N.º de documento","revision":"Revisión","client":"Cliente","approval":"Revisión y aprobación","role":"Rol","name":"Nombre","signature":"Firma","date":"Fecha","scope":"Alcance del informe","prepared_role":"Preparado por","checked_role":"Revisado por","approved_role":"Aprobado por"},
    }
    return extra[lang]
def build_professional_html(snapshot,project,options,client="",document_no="NCA-CALC-001",revision="0",logo_path=None):
    validate(options);l=options.language;rtl=direction(l)=="rtl";x=_labels(l)
    logo=f'<img src="{Path(logo_path).resolve().as_uri()}">' if logo_path and Path(logo_path).exists() else ""
    rows="".join(f"<tr><td>{escape(str(k))}</td><td class='ltr'>{escape(str(v))}</td></tr>" for k,v in snapshot["inputs"].items())
    return f"""<!doctype html><html lang="{l}" dir="{'rtl' if rtl else 'ltr'}"><head><meta charset="utf-8"><style>{_page_css(options,rtl)}</style></head><body>
    <section class="cover">{logo}<h1>{tr(l,'title')}</h1><h3>{escape(options.company_name)}</h3>
      <table class="meta"><tr><td>{tr(l,'project')}</td><td>{escape(project)}</td></tr><tr><td>{x['client']}</td><td>{escape(client or '-')}</td></tr>
      <tr><td>{x['docno']}</td><td class="ltr">{escape(document_no)}</td></tr><tr><td>{x['revision']}</td><td class="ltr">{escape(revision)}</td></tr>
      <tr><td>{tr(l,'prepared')}</td><td>{escape(options.prepared_by)}</td></tr></table></section>
    <section class="pagebreak"><h2>{x['scope']}</h2><p>{tr(l,'review')}</p>
      <h2>{tr(l,'inputs')}</h2><table class="data"><tr><th>{tr(l,'input')}</th><th>{tr(l,'value')}</th></tr>{rows}</table>
      <h2>{tr(l,'method')}</h2><p class="ltr">{escape(snapshot['method'])}</p>
      <h2>{tr(l,'result')}</h2><p>{tr(l,'motor_current')}: <b class="ltr">{snapshot['outputs']['current_a']:.2f} A</b></p>
      <p>{tr(l,'status')}: <span class="status">{escape(snapshot['status'])}</span></p>
      <p>{tr(l,'engine')}: <span class="ltr">{escape(snapshot['engine_version'])}</span></p>
      <h2>{tr(l,'trace')}</h2><p class="ltr">{tr(l,'fingerprint')}: {escape(snapshot['fingerprint'])}</p></section>
    <section class="pagebreak"><h2>{x['approval']}</h2><table class="data approval">
      <tr><th>{x['role']}</th><th>{x['name']}</th><th>{x['signature']}</th><th>{x['date']}</th></tr>
      <tr><td>{x['prepared_role']}</td><td>{escape(options.prepared_by)}</td><td></td><td></td></tr>
      <tr><td>{x['checked_role']}</td><td></td><td></td><td></td></tr><tr><td>{x['approved_role']}</td><td></td><td></td><td></td></tr></table>
      <div class="warn">{tr(l,'review')}</div></section></body></html>"""
def build_professional_pdf(path,snapshot,project,options,**kwargs):
    from weasyprint import HTML
    html=build_professional_html(snapshot,project,options,**kwargs)
    HTML(string=html,base_url=str(Path(path).parent)).write_pdf(str(path))
    return str(path)
