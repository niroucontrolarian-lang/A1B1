from __future__ import annotations
from dataclasses import dataclass
from datetime import date
import re

@dataclass
class RevisionCandidate:
    file_name: str
    document_no: str|None=None
    revision_code: str|None=None
    revision_date: str|None=None
    document_status: str|None=None
    metadata_score: float=0.0

@dataclass
class Resolution:
    latest: RevisionCandidate|None
    confidence: str
    reason: str
    ordered: list[RevisionCandidate]

def _rev_key(code: str|None):
    if not code: return (-1,"")
    c=code.strip().upper()
    m=re.fullmatch(r"(?:REV[._ -]?)?(\d+)",c)
    if m: return (int(m.group(1)), "")
    m=re.fullmatch(r"(?:REV[._ -]?)?([A-Z]+)",c)
    if m:
        n=0
        for ch in m.group(1): n=n*26+(ord(ch)-64)
        return (n,"A")
    return (-1,c)

def resolve(candidates: list[RevisionCandidate]) -> Resolution:
    if not candidates: return Resolution(None,"LOW","No candidates.",[])
    ordered=sorted(candidates,key=lambda c:(_rev_key(c.revision_code), c.revision_date or "", c.metadata_score))
    latest=ordered[-1]
    # Never treat file mtime/name alone as authoritative; unresolved metadata lowers confidence.
    confidence="HIGH" if latest.revision_code and latest.revision_date and latest.document_no else "MEDIUM"
    if sum(1 for c in candidates if c.revision_code==latest.revision_code)>1:
        confidence="LOW"
    return Resolution(latest,confidence,
        "Resolved from document number/revision/date metadata; content/status review is still required before approval.",
        ordered)
