
from dataclasses import dataclass,asdict
import json

ENGINEERING_STATUS_TOKENS={
 "PASS":"status_pass","CALCULATED":"status_pass","WARNING":"status_warning",
 "FAIL":"status_fail","BLOCKED":"status_fail","OUTDATED":"status_outdated",
 "SOURCE_REQUIRED":"status_source_required","INCOMPLETE":"status_incomplete"
}

@dataclass
class ThemePreferences:
    mode:str="system"                 # light/dark/system
    preset:str="nca_professional"
    accent:str="blue"
    font_scale:float=1.0
    density:str="comfortable"        # compact/comfortable/spacious
    rounded_cards:bool=True
    high_contrast:bool=False

    def validate(self):
        if self.mode not in {"light","dark","system"}: raise ValueError("Invalid theme mode")
        if self.density not in {"compact","comfortable","spacious"}: raise ValueError("Invalid density")
        if not 0.80<=self.font_scale<=1.40: raise ValueError("font_scale out of supported range")
        return self

PRESETS={
 "nca_professional":{"label":"NCA Professional"},
 "industrial_dark":{"label":"Industrial Dark"},
 "engineering_light":{"label":"Engineering Light"},
 "high_contrast":{"label":"High Contrast"},
}
