
import json
from nca_ui.theme import ThemePreferences
class ThemeStore:
    def __init__(self,con):
        self.con=con
        self.con.execute("""CREATE TABLE IF NOT EXISTS user_ui_preference(
          user_id TEXT PRIMARY KEY,theme_json TEXT NOT NULL,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
        self.con.commit()
    def save(self,user_id,prefs):
        prefs.validate()
        self.con.execute("""INSERT OR REPLACE INTO user_ui_preference(user_id,theme_json,updated_at)
          VALUES(?,?,CURRENT_TIMESTAMP)""",(user_id,json.dumps(prefs.__dict__,sort_keys=True)))
        self.con.commit()
    def load(self,user_id):
        r=self.con.execute("SELECT theme_json FROM user_ui_preference WHERE user_id=?",(user_id,)).fetchone()
        return ThemePreferences(**json.loads(r[0])) if r else ThemePreferences()
