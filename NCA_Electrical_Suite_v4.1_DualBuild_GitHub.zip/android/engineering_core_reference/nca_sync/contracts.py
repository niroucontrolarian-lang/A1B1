from dataclasses import dataclass, field

@dataclass
class SyncChange:
    change_id: str
    project_id: str
    object_id: str
    property_key: str
    base_revision: int
    payload: dict
    author_user_id: str

@dataclass
class SyncResult:
    applied: list[str]=field(default_factory=list)
    conflicts: list[str]=field(default_factory=list)
    rejected: list[str]=field(default_factory=list)
