
from dataclasses import dataclass, field
from typing import Optional

@dataclass
class CtRequirement:
    primary_a: float
    secondary_a: float
    burden_va: Optional[float]
    accuracy_class: Optional[str]
    protection_class: Optional[str]
    status: str
    messages: list[str]=field(default_factory=list)

def ct_requirement(load_current_a:float, preferred_secondary_a:float=1.0,
                   burden_va:float|None=None, accuracy_class:str|None=None,
                   protection_class:str|None=None)->CtRequirement:
    if load_current_a<=0 or preferred_secondary_a not in (1.0,5.0):
        return CtRequirement(0,preferred_secondary_a,burden_va,accuracy_class,protection_class,"FAIL",["Invalid CT inputs."])
    # Requirement only; no standardized primary ratio is invented.
    msgs=["Primary ratio selection remains RECOMMENDED/ENGINEER REVIEW until standard ratio, overload margin, metering/protection duty and saturation are checked."]
    status="INCOMPLETE" if burden_va is None or (accuracy_class is None and protection_class is None) else "CALCULATED"
    return CtRequirement(load_current_a,preferred_secondary_a,burden_va,accuracy_class,protection_class,status,msgs)

@dataclass
class VtRequirement:
    primary_v: float
    secondary_v: Optional[float]
    burden_va: Optional[float]
    accuracy_class: Optional[str]
    status: str

def vt_requirement(primary_v:float,secondary_v:float|None=None,burden_va:float|None=None,accuracy_class:str|None=None):
    if primary_v<=0: return VtRequirement(primary_v,secondary_v,burden_va,accuracy_class,"FAIL")
    return VtRequirement(primary_v,secondary_v,burden_va,accuracy_class,
                         "CALCULATED" if all(x is not None for x in (secondary_v,burden_va,accuracy_class)) else "INCOMPLETE")
