
import json
class SnapshotStore:
    def __init__(self,con):
        self.con=con
        self.con.execute("""CREATE TABLE IF NOT EXISTS calc_snapshot_live(
          id TEXT PRIMARY KEY,project_id TEXT NOT NULL,object_id TEXT,calculation_id TEXT NOT NULL,
          fingerprint TEXT NOT NULL,payload_json TEXT NOT NULL,created_at TEXT NOT NULL)""");self.con.commit()
    def save(self,s):
        from dataclasses import asdict
        d=asdict(s)
        self.con.execute("INSERT INTO calc_snapshot_live VALUES(?,?,?,?,?,?,?)",
          (s.id,s.project_id,s.object_id,s.calculation_id,s.fingerprint,json.dumps(d,default=str),s.created_at));self.con.commit()
    def latest(self,p,o,calc):
        r=self.con.execute("""SELECT payload_json FROM calc_snapshot_live WHERE project_id=? AND object_id=? AND calculation_id=?
          ORDER BY created_at DESC LIMIT 1""",(p,o,calc)).fetchone()
        return json.loads(r[0]) if r else None
