from .base import CalculationRegistry
from .motor import three_phase_motor_current
from .voltage_drop import three_phase_voltage_drop

def default_registry():
    r=CalculationRegistry()
    r.register("motor.three_phase.full_load_current", three_phase_motor_current)
    r.register("cable.three_phase.voltage_drop", three_phase_voltage_drop)
    return r
