
from dataclasses import dataclass
from math import sqrt

@dataclass
class ThermalResult:
    status: str
    required_mm2: float|None
    provided_mm2: float|None
    message: str

def adiabatic_required_section(fault_current_ka: float, clearing_time_s: float,
                               k_factor: float|None, provided_mm2: float|None=None) -> ThermalResult:
    if fault_current_ka<0 or clearing_time_s<=0:
        return ThermalResult("FAIL",None,provided_mm2,"Fault current must be >=0 and clearing time >0.")
    if k_factor is None:
        return ThermalResult("SOURCE_REQUIRED",None,provided_mm2,
            "A validated k factor is required; it depends on conductor/insulation/temperature conditions.")
    if k_factor<=0:
        return ThermalResult("FAIL",None,provided_mm2,"k factor must be >0.")
    req=(fault_current_ka*1000)*sqrt(clearing_time_s)/k_factor
    if provided_mm2 is None:
        return ThermalResult("CALCULATED",req,None,"Required adiabatic cross-section calculated.")
    ok=provided_mm2>=req
    return ThermalResult("PASS" if ok else "FAIL",req,provided_mm2,
                         f"Provided {provided_mm2:.2f} mm²; required {req:.2f} mm².")
