
from dataclasses import dataclass
from math import sqrt
from nca_calculations.network_fault import Z

@dataclass
class SourceModelResult:
    status:str
    z_ohm:Z|None
    messages:list[str]

def transformer_impedance(rating_kva, lv_voltage_v, uk_percent, r_percent=None):
    if rating_kva<=0 or lv_voltage_v<=0 or uk_percent is None or uk_percent<=0:
        return SourceModelResult("INCOMPLETE",None,["Valid kVA, voltage and uk% are required."])
    zbase=lv_voltage_v**2/(rating_kva*1000)
    zmag=zbase*uk_percent/100
    if r_percent is None:
        return SourceModelResult("CALCULATED",Z(0,zmag),
            ["R% unavailable: transformer impedance represented as reactive-only approximation."])
    r=zbase*r_percent/100
    if r>zmag: return SourceModelResult("FAIL",None,["R component cannot exceed impedance magnitude."])
    x=(zmag*zmag-r*r)**0.5
    return SourceModelResult("CALCULATED",Z(r,x),[])

def generator_subtransient_impedance(rating_kva, voltage_v, xdpp_pu):
    if rating_kva<=0 or voltage_v<=0 or xdpp_pu is None or xdpp_pu<=0:
        return SourceModelResult("INCOMPLETE",None,["Generator kVA, voltage and Xd'' pu are required."])
    zbase=voltage_v**2/(rating_kva*1000)
    return SourceModelResult("CALCULATED",Z(0,zbase*xdpp_pu),
        ["Initial symmetrical subtransient source approximation; machine resistance and time decay are not modeled."])
