
from __future__ import annotations
from dataclasses import dataclass
from math import sqrt

@dataclass
class TransformerFaultResult:
    status: str
    rated_current_a: float|None
    terminal_fault_ka: float|None
    warnings: list[str]

def transformer_terminal_fault(rating_kva: float, lv_voltage_v: float, uk_percent: float|None) -> TransformerFaultResult:
    if rating_kva<=0 or lv_voltage_v<=0:
        return TransformerFaultResult("FAIL",None,None,["Transformer rating and LV voltage must be > 0."])
    ir=rating_kva*1000/(sqrt(3)*lv_voltage_v)
    if uk_percent is None:
        return TransformerFaultResult("INCOMPLETE",ir,None,["Transformer uk% is required for terminal fault-current calculation."])
    if uk_percent<=0:
        return TransformerFaultResult("FAIL",ir,None,["Transformer uk% must be > 0."])
    # Simplified symmetrical RMS terminal current neglecting upstream impedance.
    ik=ir*(100/uk_percent)/1000
    return TransformerFaultResult("CALCULATED",ir,ik,
        ["Simplified transformer-terminal symmetrical RMS fault current; upstream/network and X/R effects are not included."])

@dataclass
class ImpedanceFaultResult:
    status: str
    fault_ka: float|None
    warnings: list[str]

def three_phase_fault_from_impedance(voltage_ll_v: float, r_ohm: float, x_ohm: float) -> ImpedanceFaultResult:
    if voltage_ll_v<=0 or r_ohm<0 or x_ohm<0 or (r_ohm==0 and x_ohm==0):
        return ImpedanceFaultResult("FAIL",None,["Valid voltage and non-zero positive-sequence impedance are required."])
    z=(r_ohm*r_ohm+x_ohm*x_ohm)**0.5
    ik=voltage_ll_v/(sqrt(3)*z)/1000
    return ImpedanceFaultResult("CALCULATED",ik,[])
