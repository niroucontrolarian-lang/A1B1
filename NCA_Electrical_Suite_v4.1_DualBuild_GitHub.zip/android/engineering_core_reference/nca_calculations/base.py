from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Callable
from nca_core.models import new_id, utc_now

@dataclass
class CalculationResult:
    calculation_id: str
    engine_version: str
    status: str
    inputs: dict[str, Any]
    result: dict[str, Any] = field(default_factory=dict)
    intermediate: dict[str, Any] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)
    assumptions: list[str] = field(default_factory=list)
    references: list[str] = field(default_factory=list)
    id: str = field(default_factory=new_id)
    created_at: str = field(default_factory=utc_now)

class CalculationRegistry:
    def __init__(self): self._items: dict[str, Callable[..., CalculationResult]] = {}
    def register(self, calculation_id: str, fn: Callable[..., CalculationResult]):
        if calculation_id in self._items: raise KeyError(f"Duplicate calculation: {calculation_id}")
        self._items[calculation_id]=fn
    def run(self, calculation_id: str, **kwargs) -> CalculationResult:
        if calculation_id not in self._items: raise KeyError(calculation_id)
        return self._items[calculation_id](**kwargs)
    def ids(self): return sorted(self._items)
