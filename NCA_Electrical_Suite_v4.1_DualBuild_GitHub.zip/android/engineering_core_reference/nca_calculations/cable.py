
from __future__ import annotations
from dataclasses import dataclass, field
from math import sqrt, acos, cos, sin
from typing import Optional

ENGINE_VERSION="0.4.0"

@dataclass(frozen=True)
class CableRecord:
    id: str
    conductor: str
    insulation: str
    cores: str
    size_mm2: float
    base_ampacity_a: float
    r_ohm_per_km: float
    x_ohm_per_km: float
    source_ref: str
    source_version: str

@dataclass
class CableCandidateResult:
    cable_id: str
    size_mm2: float
    corrected_ampacity_a: float
    voltage_drop_percent: float
    ampacity_ok: bool
    voltage_drop_ok: bool
    accepted: bool
    reasons: list[str]=field(default_factory=list)

def evaluate_cable(record: CableRecord, design_current_a: float, length_m: float,
                   voltage_v: float, power_factor: float,
                   ambient_factor: float=1.0, grouping_factor: float=1.0,
                   installation_factor: float=1.0, parallel_runs: int=1,
                   max_voltage_drop_percent: float=5.0) -> CableCandidateResult:
    if not record.source_ref or not record.source_version:
        raise ValueError("Cable engineering data requires source_ref and source_version.")
    if design_current_a < 0 or length_m < 0 or voltage_v <= 0:
        raise ValueError("Invalid electrical inputs.")
    if not 0 < power_factor <= 1:
        raise ValueError("Power factor must be in (0,1].")
    if parallel_runs < 1:
        raise ValueError("parallel_runs must be >= 1.")
    for f in (ambient_factor,grouping_factor,installation_factor):
        if not 0 < f <= 1.5: raise ValueError("Correction factors must be >0 and plausibly bounded.")
    iz=record.base_ampacity_a*ambient_factor*grouping_factor*installation_factor*parallel_runs
    phi=acos(power_factor); lkm=length_m/1000
    # Equal current sharing is an explicit simplifying assumption at this gate.
    i_run=design_current_a/parallel_runs
    dv=sqrt(3)*i_run*lkm*(record.r_ohm_per_km*cos(phi)+record.x_ohm_per_km*sin(phi))
    pct=100*dv/voltage_v
    aok=iz>=design_current_a; vok=pct<=max_voltage_drop_percent
    reasons=[]
    if not aok: reasons.append(f"Ampacity rejected: corrected Iz={iz:.2f} A < Ib={design_current_a:.2f} A.")
    if not vok: reasons.append(f"Voltage drop rejected: {pct:.2f}% > {max_voltage_drop_percent:.2f}%.")
    if aok and vok: reasons.append("Passes ampacity and voltage-drop gates; short-circuit thermal/PE/protection checks remain.")
    return CableCandidateResult(record.id,record.size_mm2,iz,pct,aok,vok,aok and vok,reasons)

def rank_candidates(records, **kwargs):
    results=[evaluate_cable(r,**kwargs) for r in records]
    return sorted(results,key=lambda x:(not x.accepted,x.size_mm2,x.voltage_drop_percent))
