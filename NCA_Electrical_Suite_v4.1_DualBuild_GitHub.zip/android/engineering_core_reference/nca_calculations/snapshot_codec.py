from .evidence import CalculationSnapshot,Assumption

def snapshot_from_dict(d):
    return CalculationSnapshot(**{**d,"assumptions":[Assumption(**a) for a in d.get("assumptions",[])]})
