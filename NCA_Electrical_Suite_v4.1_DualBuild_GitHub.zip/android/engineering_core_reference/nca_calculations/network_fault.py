
from __future__ import annotations
from dataclasses import dataclass, field
from math import sqrt

@dataclass(frozen=True)
class Z:
    r: float
    x: float
    def __add__(self,o): return Z(self.r+o.r,self.x+o.x)
    @property
    def mag(self): return (self.r*self.r+self.x*self.x)**0.5

@dataclass
class NetworkNode:
    id: str
    parent_id: str|None
    series_z_ohm: Z
    voltage_ll_v: float

@dataclass
class FaultAtNode:
    node_id: str
    status: str
    ik_ka: float|None
    total_z: Z|None
    messages: list[str]=field(default_factory=list)

class RadialFaultNetwork:
    def __init__(self, source_z: Z):
        self.source_z=source_z; self.nodes={}
    def add(self,n:NetworkNode):
        if n.id in self.nodes: raise ValueError("Duplicate network node.")
        if n.parent_id and n.parent_id not in self.nodes: raise ValueError("Parent node must exist first.")
        if n.voltage_ll_v<=0 or n.series_z_ohm.r<0 or n.series_z_ohm.x<0: raise ValueError("Invalid node data.")
        self.nodes[n.id]=n
    def total_z(self,node_id):
        z=self.source_z; cur=self.nodes[node_id]; seen=set()
        while True:
            if cur.id in seen: raise ValueError("Network cycle detected.")
            seen.add(cur.id); z=z+cur.series_z_ohm
            if not cur.parent_id: break
            cur=self.nodes[cur.parent_id]
        return z
    def fault(self,node_id):
        n=self.nodes[node_id]; z=self.total_z(node_id)
        if z.mag<=0: return FaultAtNode(node_id,"INCOMPLETE",None,z,["Equivalent impedance must be non-zero."])
        ik=n.voltage_ll_v/(sqrt(3)*z.mag)/1000
        return FaultAtNode(node_id,"CALCULATED",ik,z,["Radial positive-sequence symmetrical RMS model."])
    def scenario(self,node_id,z_tolerance:float=0.10):
        if not 0<=z_tolerance<1: raise ValueError("z_tolerance must be in [0,1).")
        base=self.total_z(node_id); v=self.nodes[node_id].voltage_ll_v
        # Engineering scenario envelope, not a standards voltage-factor implementation.
        zmin=Z(base.r*(1-z_tolerance),base.x*(1-z_tolerance))
        zmax=Z(base.r*(1+z_tolerance),base.x*(1+z_tolerance))
        return {
          "max_fault_ka": v/(sqrt(3)*zmin.mag)/1000,
          "min_fault_ka": v/(sqrt(3)*zmax.mag)/1000,
          "assumption": f"Illustrative ±{z_tolerance*100:.1f}% impedance scenario; replace with project/standard-defined min/max inputs."
        }
