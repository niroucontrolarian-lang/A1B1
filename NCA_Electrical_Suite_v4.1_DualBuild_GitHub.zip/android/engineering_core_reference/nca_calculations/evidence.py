
from __future__ import annotations
from dataclasses import dataclass,field,asdict
from typing import Any
import datetime,hashlib,json,uuid

@dataclass
class Assumption:
    key:str
    value:Any
    unit:str|None=None
    source:str|None=None
    status:str="ASSUMED"

@dataclass
class CalculationSnapshot:
    id:str
    calculation_id:str
    engine_version:str
    project_id:str
    object_id:str|None
    inputs:dict
    assumptions:list[Assumption]
    method:str
    reference:str|None
    intermediates:dict
    outputs:dict
    status:str
    warnings:list[str]
    created_at:str
    fingerprint:str

def create_snapshot(calculation_id,engine_version,project_id,object_id,inputs,assumptions,
                    method,reference,intermediates,outputs,status,warnings):
    payload={"calculation_id":calculation_id,"engine_version":engine_version,"project_id":project_id,
             "object_id":object_id,"inputs":inputs,"assumptions":[asdict(a) for a in assumptions],
             "method":method,"reference":reference,"intermediates":intermediates,"outputs":outputs,
             "status":status,"warnings":warnings}
    fp=hashlib.sha256(json.dumps(payload,sort_keys=True,default=str).encode()).hexdigest()
    return CalculationSnapshot(str(uuid.uuid4()),calculation_id,engine_version,project_id,object_id,
        inputs,assumptions,method,reference,intermediates,outputs,status,warnings,
        datetime.datetime.now(datetime.timezone.utc).isoformat(),fp)
