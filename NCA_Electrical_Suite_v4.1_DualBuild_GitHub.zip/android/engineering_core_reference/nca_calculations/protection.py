
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional

@dataclass(frozen=True)
class BreakerCandidate:
    id: str
    rated_current_a: float
    breaking_capacity_ka: Optional[float]
    adjustable_min_a: Optional[float]=None
    adjustable_max_a: Optional[float]=None
    manufacturer: Optional[str]=None
    model: Optional[str]=None
    source_ref: Optional[str]=None
    source_version: Optional[str]=None

@dataclass
class BreakerEvaluation:
    candidate_id: str
    status: str
    current_ok: bool
    breaking_ok: Optional[bool]
    reasons: list[str]=field(default_factory=list)

def evaluate_breaker(c: BreakerCandidate, design_current_a: float, cable_capacity_a: float,
                     max_fault_ka: Optional[float]) -> BreakerEvaluation:
    reasons=[]
    # Generic feeder gate. Final protection settings/selectivity require device data and coordination study.
    current_ok = design_current_a <= c.rated_current_a <= cable_capacity_a
    if not current_ok:
        reasons.append(f"Required Ib ≤ In ≤ Iz not met ({design_current_a:.2f} ≤ {c.rated_current_a:.2f} ≤ {cable_capacity_a:.2f}).")
    if max_fault_ka is None or c.breaking_capacity_ka is None:
        breaking_ok=None
        reasons.append("Breaking-capacity verification incomplete: Icu/Icn or prospective fault level missing.")
    else:
        breaking_ok=c.breaking_capacity_ka>=max_fault_ka
        if not breaking_ok: reasons.append(f"Breaking capacity {c.breaking_capacity_ka:.2f} kA < Ik,max {max_fault_ka:.2f} kA.")
    if c.manufacturer or c.model:
        if not c.source_ref or not c.source_version:
            reasons.append("Manufacturer/model candidate is SOURCE REQUIRED until official source/version is attached.")
            return BreakerEvaluation(c.id,"SOURCE_REQUIRED",current_ok,breaking_ok,reasons)
    status="PASS" if current_ok and breaking_ok is True else ("INCOMPLETE" if current_ok and breaking_ok is None else "FAIL")
    if status=="PASS": reasons.append("Generic current and breaking-capacity gates passed; coordination/settings remain.")
    return BreakerEvaluation(c.id,status,current_ok,breaking_ok,reasons)
