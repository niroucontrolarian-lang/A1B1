
from dataclasses import dataclass, field
from typing import Optional

@dataclass
class ProtectionPoint:
    device_id: str
    pickup_a: Optional[float]=None
    trip_time_s: Optional[float]=None
    curve_ref: Optional[str]=None
    source_ref: Optional[str]=None

@dataclass
class CoordinationResult:
    status: str
    margin_s: Optional[float]
    messages: list[str]=field(default_factory=list)

def time_margin(downstream: ProtectionPoint, upstream: ProtectionPoint,
                required_margin_s: float) -> CoordinationResult:
    if downstream.trip_time_s is None or upstream.trip_time_s is None:
        return CoordinationResult("INCOMPLETE",None,["Both operating times are required at the same fault-current point."])
    if (downstream.curve_ref or upstream.curve_ref) and (not downstream.source_ref or not upstream.source_ref):
        return CoordinationResult("SOURCE_REQUIRED",None,["Device curve references require traceable manufacturer/source data."])
    margin=upstream.trip_time_s-downstream.trip_time_s
    ok=margin>=required_margin_s
    return CoordinationResult("PASS" if ok else "FAIL",margin,
        [f"Time margin={margin:.3f} s; required ≥ {required_margin_s:.3f} s.",
         "This point check is not a claim of full selectivity across the complete current range."])
