from __future__ import annotations
from math import sqrt, cos, sin, acos
from .base import CalculationResult

ENGINE_VERSION="0.2.0"
CALC_ID="cable.three_phase.voltage_drop"

def three_phase_voltage_drop(current_a: float, length_m: float, voltage_v: float,
                             r_ohm_per_km: float, x_ohm_per_km: float,
                             power_factor: float) -> CalculationResult:
    inputs=locals().copy()
    errors=[]
    if current_a < 0 or length_m < 0: errors.append("Current and length cannot be negative.")
    if voltage_v <= 0: errors.append("Voltage must be > 0 V.")
    if r_ohm_per_km < 0 or x_ohm_per_km < 0: errors.append("Cable R/X cannot be negative.")
    if not 0 < power_factor <= 1: errors.append("Power factor must be in (0,1].")
    if errors: return CalculationResult(CALC_ID,ENGINE_VERSION,"FAIL",inputs,warnings=errors)
    phi=acos(power_factor)
    l_km=length_m/1000.0
    dv=sqrt(3)*current_a*l_km*(r_ohm_per_km*cos(phi)+x_ohm_per_km*sin(phi))
    pct=100*dv/voltage_v
    return CalculationResult(CALC_ID,ENGINE_VERSION,"CALCULATED",inputs,
        result={"voltage_drop_v":dv,"voltage_drop_percent":pct},
        intermediate={"length_km":l_km,"phi_rad":phi})
