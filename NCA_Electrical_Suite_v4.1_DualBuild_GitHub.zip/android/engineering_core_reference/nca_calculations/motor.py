from __future__ import annotations
from math import sqrt
from .base import CalculationResult

ENGINE_VERSION="0.2.0"
CALC_ID="motor.three_phase.full_load_current"

def three_phase_motor_current(power_kw: float, voltage_v: float, efficiency: float,
                              power_factor: float) -> CalculationResult:
    inputs=locals().copy()
    errors=[]
    if power_kw <= 0: errors.append("Motor power must be > 0 kW.")
    if voltage_v <= 0: errors.append("Voltage must be > 0 V.")
    if not 0 < efficiency <= 1: errors.append("Efficiency must be in (0,1].")
    if not 0 < power_factor <= 1: errors.append("Power factor must be in (0,1].")
    if errors:
        return CalculationResult(CALC_ID,ENGINE_VERSION,"FAIL",inputs,warnings=errors)
    p_out_w=power_kw*1000.0
    p_in_w=p_out_w/efficiency
    current_a=p_out_w/(sqrt(3)*voltage_v*efficiency*power_factor)
    return CalculationResult(
        CALC_ID, ENGINE_VERSION, "CALCULATED", inputs,
        result={"full_load_current_a": current_a, "electrical_input_kw": p_in_w/1000.0},
        intermediate={"sqrt3": sqrt(3), "mechanical_output_w": p_out_w, "electrical_input_w": p_in_w},
        references=["Three-phase active-power relationship; project assumptions must identify whether entered kW is shaft output or electrical input."]
    )
