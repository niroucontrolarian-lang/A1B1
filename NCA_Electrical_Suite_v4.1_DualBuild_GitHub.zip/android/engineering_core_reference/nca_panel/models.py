from dataclasses import dataclass

@dataclass
class PanelPlacement:
    engineering_object_id: str
    x_mm: float; y_mm: float; z_mm: float
    width_mm: float; height_mm: float; depth_mm: float
    rotation_deg: float=0.0
    mounting_surface: str="MOUNTING_PLATE"

def boxes_intersect(a: PanelPlacement,b: PanelPlacement) -> bool:
    return not (
        a.x_mm+a.width_mm <= b.x_mm or b.x_mm+b.width_mm <= a.x_mm or
        a.y_mm+a.height_mm <= b.y_mm or b.y_mm+b.height_mm <= a.y_mm or
        a.z_mm+a.depth_mm <= b.z_mm or b.z_mm+b.depth_mm <= a.z_mm
    )
