
from dataclasses import dataclass

@dataclass
class SensitivityResult:
    status:str
    multiple:float|None
    message:str

def pickup_sensitivity(min_fault_a, pickup_a, required_multiple):
    if min_fault_a is None:
        return SensitivityResult("INCOMPLETE",None,"Minimum fault current is required.")
    if pickup_a<=0 or required_multiple<=0:
        return SensitivityResult("FAIL",None,"Pickup and required multiple must be >0.")
    m=min_fault_a/pickup_a
    return SensitivityResult("PASS" if m>=required_multiple else "FAIL",m,
        f"Imin/Ipickup={m:.3f}; required ≥ {required_multiple:.3f}.")
