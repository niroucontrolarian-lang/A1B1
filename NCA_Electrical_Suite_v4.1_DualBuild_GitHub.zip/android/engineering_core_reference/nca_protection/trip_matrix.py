
from dataclasses import dataclass

@dataclass(frozen=True)
class TripAction:
    cause:str
    target_device:str
    action:str
    reset:str
    source:str|None=None

def validate_trip_matrix(actions):
    issues=[]
    seen=set()
    for a in actions:
        k=(a.cause,a.target_device,a.action)
        if k in seen: issues.append(f"Duplicate trip action: {k}")
        seen.add(k)
        if a.action not in ("TRIP","ALARM","BLOCK","START","STOP"):
            issues.append(f"Unsupported action: {a.action}")
    return issues
