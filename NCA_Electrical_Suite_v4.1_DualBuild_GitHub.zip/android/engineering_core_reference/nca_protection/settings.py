
from dataclasses import dataclass, field
from typing import Any
from nca_protection.functions import SettingState

@dataclass
class SettingRecord:
    function_code: str
    parameter_key: str
    engineering_value: Any
    engineering_unit: str|None
    state: SettingState=SettingState.CALCULATED
    device_value: Any=None
    device_parameter_name: str|None=None
    device_parameter_number: str|None=None
    source_ref: str|None=None
    source_version: str|None=None
    approved_by: str|None=None
    as_set_value: Any=None
    history: list[dict]=field(default_factory=list)

    def map_device(self,value,parameter_name,parameter_number,source_ref,source_version):
        if not source_ref or not source_version:
            raise ValueError("Official/validated device source and version are required.")
        self.device_value=value; self.device_parameter_name=parameter_name
        self.device_parameter_number=parameter_number; self.source_ref=source_ref
        self.source_version=source_version; self.state=SettingState.DEVICE_MAPPED
        self.history.append({"action":"DEVICE_MAPPED","value":value})
    def approve(self,user_id):
        if self.state!=SettingState.DEVICE_MAPPED: raise ValueError("Only mapped settings can be engineer-approved.")
        self.approved_by=user_id; self.state=SettingState.ENGINEER_APPROVED
        self.history.append({"action":"ENGINEER_APPROVED","user":user_id})
    def record_as_set(self,value):
        if self.state!=SettingState.ENGINEER_APPROVED: raise ValueError("Engineer approval required before As-Set.")
        self.as_set_value=value; self.state=SettingState.AS_SET
        self.history.append({"action":"AS_SET","value":value})
