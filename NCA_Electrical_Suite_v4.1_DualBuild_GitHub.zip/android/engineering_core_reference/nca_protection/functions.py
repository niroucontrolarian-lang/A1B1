
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

class SettingState(str,Enum):
    CALCULATED="CALCULATED"
    DEVICE_MAPPED="DEVICE_MAPPED"
    ENGINEER_APPROVED="ENGINEER_APPROVED"
    AS_SET="AS_SET"

@dataclass
class ProtectionFunction:
    code: str
    enabled: bool=False
    requirement: dict[str,Any]=field(default_factory=dict)
    applicability_note: str=""
    status: str="INCOMPLETE"

SUPPORTED_FUNCTIONS={
 "50":"Instantaneous phase overcurrent",
 "51":"Time phase overcurrent",
 "50N":"Instantaneous earth/neutral overcurrent",
 "51N":"Time earth/neutral overcurrent",
 "49":"Thermal overload",
 "46":"Negative-sequence/unbalance",
 "27":"Undervoltage",
 "59":"Overvoltage",
}

def new_function(code:str)->ProtectionFunction:
    if code not in SUPPORTED_FUNCTIONS: raise ValueError("Protection function not in current v0.6 catalog.")
    return ProtectionFunction(code,False,{},SUPPORTED_FUNCTIONS[code],"INCOMPLETE")
