
from dataclasses import dataclass,field

@dataclass
class ProtectionZone:
    id:str
    name:str
    protected_object_ids:set[str]=field(default_factory=set)
    primary_device_ids:set[str]=field(default_factory=set)
    backup_device_ids:set[str]=field(default_factory=set)

def audit_zones(zones,required_objects):
    coverage={x:[] for x in required_objects}
    for z in zones:
        for x in z.protected_object_ids:
            if x in coverage: coverage[x].append(z.id)
    gaps=[x for x,v in coverage.items() if not v]
    overlaps={x:v for x,v in coverage.items() if len(v)>1}
    return {"status":"PASS" if not gaps else "FAIL","gaps":gaps,"overlaps":overlaps}
