from dataclasses import dataclass

@dataclass
class RuleResult:
    rule_id: str
    status: str
    message: str

def check_ib_in_iz(ib_a: float, protective_rating_a: float, cable_capacity_a: float) -> RuleResult:
    if min(ib_a, protective_rating_a, cable_capacity_a) < 0:
        return RuleResult("LV.FEEDER.IB_IN_IZ","FAIL","Negative current/rating is invalid.")
    ok = ib_a <= protective_rating_a <= cable_capacity_a
    return RuleResult(
        "LV.FEEDER.IB_IN_IZ",
        "PASS" if ok else "FAIL",
        f"Ib={ib_a:g} A, In={protective_rating_a:g} A, Iz={cable_capacity_a:g} A; required Ib ≤ In ≤ Iz."
    )

def check_breaking_capacity(icu_ka: float|None, max_fault_ka: float|None) -> RuleResult:
    if icu_ka is None or max_fault_ka is None:
        return RuleResult("LV.PROTECTION.BREAKING_CAPACITY","INCOMPLETE",
                          "Icu and maximum prospective fault current are both required.")
    ok=icu_ka >= max_fault_ka
    return RuleResult("LV.PROTECTION.BREAKING_CAPACITY","PASS" if ok else "FAIL",
                      f"Icu={icu_ka:g} kA; Ik,max={max_fault_ka:g} kA.")
