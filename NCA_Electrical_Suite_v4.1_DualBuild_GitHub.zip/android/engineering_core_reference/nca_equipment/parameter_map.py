
from dataclasses import dataclass

@dataclass(frozen=True)
class ParameterMapEntry:
    engineering_key:str
    device_parameter_name:str
    device_parameter_number:str|None
    unit:str|None
    source_ref:str
    source_version:str
    firmware_scope:str|None=None

def validate_parameter_map(entries):
    issues=[]
    keys=set()
    for e in entries:
        if not e.source_ref or not e.source_version:
            issues.append(f"{e.engineering_key}: SOURCE_REQUIRED")
        if e.engineering_key in keys: issues.append(f"Duplicate engineering key: {e.engineering_key}")
        keys.add(e.engineering_key)
    return issues
