
from dataclasses import dataclass,field

@dataclass
class DeviceRequirement:
    voltage_v:float|None=None
    current_a:float|None=None
    functions:set[str]=field(default_factory=set)
    protocol:str|None=None

@dataclass
class DeviceCandidate:
    id:str
    voltage_min_v:float|None=None
    voltage_max_v:float|None=None
    current_max_a:float|None=None
    functions:set[str]=field(default_factory=set)
    protocols:set[str]=field(default_factory=set)
    manufacturer:str|None=None
    model:str|None=None
    source_ref:str|None=None
    source_version:str|None=None

def check_compatibility(req,c):
    reasons=[]
    if (c.manufacturer or c.model) and (not c.source_ref or not c.source_version):
        return {"status":"SOURCE_REQUIRED","reasons":["Exact manufacturer/model data needs validated source/version."]}
    if req.voltage_v is not None and None not in (c.voltage_min_v,c.voltage_max_v):
        if not c.voltage_min_v<=req.voltage_v<=c.voltage_max_v: reasons.append("Voltage range incompatible.")
    if req.current_a is not None and c.current_max_a is not None and req.current_a>c.current_max_a:
        reasons.append("Current requirement exceeds candidate capability.")
    missing=req.functions-c.functions
    if missing: reasons.append("Missing protection functions: "+",".join(sorted(missing)))
    if req.protocol and req.protocol not in c.protocols: reasons.append("Required protocol unavailable.")
    return {"status":"INCOMPATIBLE" if reasons else "COMPATIBLE","reasons":reasons}
