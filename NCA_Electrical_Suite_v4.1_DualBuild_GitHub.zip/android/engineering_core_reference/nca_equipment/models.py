from dataclasses import dataclass, field
from typing import Any

@dataclass
class SourceDocument:
    title: str
    official_url: str|None
    revision: str|None
    verified_at: str|None

@dataclass
class ManufacturerProduct:
    manufacturer: str
    category: str
    series: str|None
    model: str|None
    part_number: str|None
    lifecycle_status: str="UNDER_REVIEW"
    data: dict[str,Any]=field(default_factory=dict)
    sources: list[SourceDocument]=field(default_factory=list)

    @property
    def verified(self) -> bool:
        return bool(self.sources) and all(s.official_url for s in self.sources)
