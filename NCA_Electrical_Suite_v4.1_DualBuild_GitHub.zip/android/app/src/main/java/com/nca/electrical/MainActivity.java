package com.nca.electrical;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.widget.Toast;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int OPEN_PROJECT = 8001;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(15,23,42));
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        webView.addJavascriptInterface(new NativeBridge(), "NCA");
        webView.setWebViewClient(new WebViewClient()); webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html"); setContentView(webView);
    }

    public class NativeBridge {
        @JavascriptInterface public void printPage() { runOnUiThread(() -> {
            try {
                PrintManager pm=(PrintManager)getSystemService(Context.PRINT_SERVICE);
                String name="NCA_Engineering_Report_"+System.currentTimeMillis();
                pm.print(name, webView.createPrintDocumentAdapter(name), new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());
            } catch(Exception e){ Toast.makeText(MainActivity.this,"Print error: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
        }); }

        @JavascriptInterface public void saveProjectJson(String filename, String content) {
            try {
                String safe=(filename==null||filename.trim().isEmpty())?"NCA_Project.json":filename.replaceAll("[^a-zA-Z0-9._-]","_");
                if(!safe.endsWith(".json")) safe += ".json";
                if(Build.VERSION.SDK_INT>=29){
                    ContentValues cv=new ContentValues(); cv.put(MediaStore.Downloads.DISPLAY_NAME,safe); cv.put(MediaStore.Downloads.MIME_TYPE,"application/json");
                    Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,cv);
                    if(uri==null) throw new Exception("Cannot create download");
                    try(OutputStream os=getContentResolver().openOutputStream(uri)){ os.write(content.getBytes(StandardCharsets.UTF_8)); }
                    runOnUiThread(() -> Toast.makeText(MainActivity.this,"Project saved in Downloads",Toast.LENGTH_LONG).show());
                } else {
                    java.io.File f=new java.io.File(getExternalFilesDir(null),safe);
                    try(java.io.FileOutputStream fos=new java.io.FileOutputStream(f)){fos.write(content.getBytes(StandardCharsets.UTF_8));}
                    runOnUiThread(() -> Toast.makeText(MainActivity.this,"Saved: "+f.getAbsolutePath(),Toast.LENGTH_LONG).show());
                }
            } catch(Exception e){ runOnUiThread(() -> Toast.makeText(MainActivity.this,"Save error: "+e.getMessage(),Toast.LENGTH_LONG).show()); }
        }

        @JavascriptInterface public void chooseProjectJson(){ runOnUiThread(() -> {
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/json"); startActivityForResult(i,OPEN_PROJECT);
        }); }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==OPEN_PROJECT && resultCode==RESULT_OK && data!=null && data.getData()!=null){
            try(InputStream in=getContentResolver().openInputStream(data.getData()); ByteArrayOutputStream out=new ByteArrayOutputStream()){
                byte[] buf=new byte[4096]; int n; while((n=in.read(buf))>0) out.write(buf,0,n);
                String json=out.toString("UTF-8");
                webView.evaluateJavascript("importProjectJson("+JSONObject.quote(json)+")",null);
            } catch(Exception e){Toast.makeText(this,"Import error: "+e.getMessage(),Toast.LENGTH_LONG).show();}
        }
    }

    @Override public void onBackPressed(){ if(webView!=null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
