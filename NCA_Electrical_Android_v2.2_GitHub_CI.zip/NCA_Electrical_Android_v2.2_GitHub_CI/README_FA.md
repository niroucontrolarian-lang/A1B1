# NCA Electrical Engineering Suite Android v2.0

این پروژه نسخه Android MVP نرم‌افزار NCA است و برای Build در Android Studio آماده شده است.

## ساخت APK
1. پروژه را در Android Studio باز کنید.
2. اجازه دهید Gradle و Android SDK همگام‌سازی شوند.
3. از منوی Build > Build App Bundle(s) / APK(s) > Build APK(s) استفاده کنید.
4. فایل خروجی در `app/build/outputs/apk/debug/app-debug.apk` قرار می‌گیرد.

## وضعیت این بسته
- رابط Offline مبتنی بر WebView
- محاسبه جریان موتور سه‌فاز
- تخمین افت ولتاژ کابل
- WHY / Evidence
- Engineering Change: Propose / Commit / Cancel
- Project Health
- Report Preview پنج‌زبانه: فارسی، انگلیسی، فرانسوی، عربی، اسپانیایی
- Theme روشن/تیره و Accent
- ذخیره محلی با localStorage

این نسخه MVP است و جایگزین کامل هسته Python نسخه v1.9 نیست. در ادامه، ماژول‌های Cable/Protection/Transformer/Generator/Busbar/Panel به هسته اندروید منتقل می‌شوند.
